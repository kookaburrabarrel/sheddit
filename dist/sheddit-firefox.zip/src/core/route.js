/**
 * route.js — classifies the current URL and fires change events.
 *
 * Reddit is a client-side-routed app and the `navigation` API is available on the page
 * in Chrome (verified). We prefer it, and fall back to the bridge's history relay where
 * it does not exist — Firefox's ESR line has no navigation API (it landed in Firefox 147,
 * later than the 140 ESR; measured absent in ESR 128, present in release 154), so the relay
 * is the only route signal there.
 *
 * THE TRAP IN THE NAVIGATION API — read before touching start().
 *
 * The `navigate` event is PRE-COMMIT: while it dispatches, `location.*` still holds the
 * OLD URL — that is why the event carries `event.destination.url` at all. And queueing a
 * microtask does not escape that window: microtasks drain when the stack empties, which is
 * still before the URL update for an intercepted navigation. Traced live on a real sort-tab
 * click: listener saw loc=/r/programming/, the microtask STILL saw /r/programming/, and only
 * the next task saw /r/programming/new/.
 *
 * The first version queued a microtask and read `location.pathname` inside it — so it
 * classified the page we were LEAVING. Worse, it wrote its change-detection latch
 * unconditionally, so the stale read was recorded as "seen" and the real navigation never
 * produced a second emit. Every sort change was either swallowed (URL updates, content
 * stays) or handled one navigation late (content updates, URL doesn't) — a permanent
 * one-navigation phase error, alternating between the two reported symptoms. See
 * docs/engineering-log.md bug 34.
 */
globalThis.SHD = globalThis.SHD || {};

SHD.route = (() => {
  const LISTING = 'LISTING';
  const COMMENTS = 'COMMENTS';
  const PROFILE = 'PROFILE';
  const OTHER = 'OTHER';

  const listeners = new Set();
  let current = null;

  /**
   * The one sort list. chrome.js renders tabs from this, and classify() accepts exactly
   * these — otherwise we ship tabs that route to OTHER and clicking our own UI drops the
   * user out of the extension. That happened: `controversial` was accepted under /r/x/
   * but not at the root, while the tab menu offered it on the front page.
   */
  const SORTS = ['hot', 'new', 'rising', 'controversial', 'top'];
  /* Reddit's own default front-page sort. Not a tab we render, but a URL we must accept. */
  const EXTRA_SORTS = ['best'];
  const SORT_RE = [...SORTS, ...EXTRA_SORTS].join('|');

  /* The time window `top` and `controversial` are ranked over, owned here for the same
     reason SORTS is: chrome.js renders the strip from this list, and the `t` values have
     to agree with what sortParamOf() watches or a click changes the URL and nothing
     re-renders. Reddit's own parameter values; old reddit's own labels.

     Only these two sorts take a window. `hot`, `new` and `rising` ignore `t` entirely —
     rendering the strip there would offer a control that changes nothing, which is the
     shape of bug 62 and of the tab that routed to OTHER (bug 10). */
  const TIMED_SORTS = ['top', 'controversial'];
  /* `phrase` is the same period in a SENTENCE, for the empty-listing line ("no posts
     from the past week"). Written out rather than derived from `label`, because the
     derivation is "the " + label with one exception — `all time` takes no article — and a
     rule with an exception per row is a rule that breaks the next time a period is added. */
  const TIMES = [
    { id: 'hour', label: 'past hour', phrase: 'the past hour' },
    { id: 'day', label: 'past 24 hours', phrase: 'the past 24 hours' },
    { id: 'week', label: 'past week', phrase: 'the past week' },
    { id: 'month', label: 'past month', phrase: 'the past month' },
    { id: 'year', label: 'past year', phrase: 'the past year' },
    { id: 'all', label: 'all time', phrase: 'all time' }
  ];

  /* The one profile tab list, owned here for the same reason SORTS is: chrome.js renders
     tabs from it, and every href those tabs carry must classify back to PROFILE — a tab
     that routes to OTHER drops the reader out of the extension (bug 10). `path` is the
     segment appended to /user/<name>/. */
  const PROFILE_TABS = [
    { id: 'overview', path: '', label: 'overview' },
    { id: 'comments', path: 'comments/', label: 'comments' },
    { id: 'submitted', path: 'submitted/', label: 'submitted' }
  ];

  /**
   * The hosts this extension actually rebuilds.
   *
   * Reddit serves a dozen subdomains and only some of them are the site this extension
   * imitates: `business.`, `ads.`, `mod.`, `chat.` and `support.` are separate
   * applications with their own markup, `old.` and `np.` already serve the layout this
   * one is imitating, and `new.` serves the 2018 redesign, which is a third DOM again.
   *
   * Measured live with the content scripts matched on `*://*.reddit.com/*`:
   * business.reddit.com — a marketing site with no feed at all — came back carrying
   * `html.shd-gate`, i.e. `visibility: hidden`, plus our version and theme stamps, and
   * stayed blanked until the 1500ms tick. `classify()` cannot catch that on its own,
   * because it reads only the PATH and `/` on any host is a listing.
   *
   * The manifest's `matches` is the real fence and carries the same list. This is the
   * second one, and it is not redundant: a match pattern is one careless edit away from
   * widening, the blackout runs before anything else we ship, and a page we do not render
   * must never be blanked whatever delivered us onto it.
   */
  const RENDER_HOSTS = /^(?:www\.|sh\.)?reddit\.com$/i;
  const rendersHost = (host) =>
    RENDER_HOSTS.test(typeof host === 'string' ? host : location.hostname);

  function classify(path = emitPath()) {
    if (/^\/r\/[^/]+\/comments\//.test(path)) return COMMENTS;
    if (path === '/' || path === '') return LISTING;
    if (/^\/r\/[^/]+\/?$/.test(path)) return LISTING;
    if (new RegExp(`^/r/[^/]+/(${SORT_RE})/?$`).test(path)) return LISTING;
    if (new RegExp(`^/(${SORT_RE})/?$`).test(path)) return LISTING;
    /* User profiles: the overview and its comments/submitted tabs, and nothing deeper.
       `/user/x/comments/` (exact) is the profile's comments TAB; `/user/x/comments/<id>/…`
       is a thread on a PROFILE POST — a page shape nobody has captured — and the `$`
       anchors below are what keep it OTHER (untouched) rather than half-claimed. In scope
       by project decision 2026-08-21; see C.PROFILE_COMMENT for what remains unverified. */
    if (/^\/user\/[^/]+\/?$/.test(path)) return PROFILE;
    if (/^\/user\/[^/]+\/(overview|comments|submitted)\/?$/.test(path)) return PROFILE;
    return OTHER;                       // search, chat, modmail, profile threads → hands off
  }

  function usernameOf(path = emitPath()) {
    const m = path.match(/^\/user\/([^/]+)/);
    return m ? m[1] : null;
  }

  function profileTabOf(path = emitPath()) {
    const m = path.match(/^\/user\/[^/]+\/(comments|submitted)\/?$/);
    return m ? m[1] : 'overview';
  }

  /**
   * The path this module last emitted for — the page we consider ourselves to be on.
   * During the pre-commit window this is AHEAD of location.pathname, which is the point:
   * anything downstream that asks "which sort are we showing" (chrome.js's active tab,
   * the sidebar's subreddit name) must agree with the render it is decorating, not with a
   * URL that may be one navigation behind or ahead. subredditOf/sortOf below default to
   * this for exactly that reason.
   */
  const emitPath = () => emit.lastPath || location.pathname;

  function subredditOf(path = emitPath()) {
    const m = path.match(/^\/r\/([^/]+)/);
    return m ? m[1] : null;
  }

  /* A SORT ONLY COUNTS WHERE REDDIT PUTS ONE, and the anchors are the point. Matching a
     sort name anywhere at the end of the path reads `/r/top/` — a real subreddit, as are
     /r/new, /r/best, /r/rising and /r/controversial — as the SORT `top` on no subreddit,
     because the trailing segment is both. chrome.js draws the tab bar and the `links from`
     period strip off this answer, so that page came up with a tab bolded it never asked
     for and, since TIMED_SORTS carries top and controversial, a window strip over a
     default listing: a control that changes nothing, which route.js already refuses to
     draw elsewhere for exactly the reason in bug 62 and bug 10.

     So the sort has to sit where a sort can sit: the whole path on the front page
     (`/top/`), or the segment after a subreddit (`/r/aww/top/`). Anywhere else the
     trailing name belongs to something that merely shares the word. */
  function sortOf(path = emitPath()) {
    const m = path.match(new RegExp(`^/(?:r/[^/]+/)?(${SORT_RE})/?$`));
    return m ? m[1] : 'hot';
  }

  /**
   * The query half of a route's identity — the parameters that change WHICH content
   * Reddit serves, and nothing else.
   *
   * Sorting a COMMENTS page is a QUERY-ONLY navigation: the sort strip's links carry
   * `?sort=new` on the post's own permalink, Reddit's router intercepts them, and the
   * pathname never moves. A latch keyed on pathname alone concluded nothing had happened —
   * so nothing tore down, the sort strip kept the old sort bold, and the pipeline consumed
   * Reddit's replacement tree UNDER the stale render: two sorts interleaved on one page,
   * with a hard reload of the same URL rendering fine (docs/engineering-log.md bug 87 —
   * bug 34's mixed-sorts family, through the door a path key cannot see).
   *
   * `t` joins it for the same reason one release later: a LISTING's time window is also
   * query-only (`/top/?t=month`), so without it the period strip would change the URL,
   * Reddit would swap the feed, and the pipeline would append the new window's posts
   * under the old window's rows — bug 87 again, on the other page type.
   *
   * ONLY these two take part, deliberately: keying on the whole query string would tear
   * the page down — scroll position, loaded pages and all — for any tracking or view
   * parameter Reddit rewrites in place, which it does. Each is harmless on the page type
   * that ignores it: a listing sorts by path segment, and a comments page has no window.
   */
  const CONTENT_PARAMS = ['sort', 't'];
  const sortParamOf = (search) => CONTENT_PARAMS
    .map((k) => {
      const m = new RegExp(`[?&]${k}=([^&#]*)`).exec(search || '');
      return m ? `${k}=${m[1]}` : '';
    })
    .filter(Boolean)
    .join('&');

  /** The emitted time window, or '' — the strip reads this, never location.search. */
  const timeOf = () => {
    const m = /(?:^|&)t=([^&]*)/.exec(emit.lastSort || '');
    return m ? m[1] : '';
  };

  /**
   * Fire listeners when the route changes.
   *
   * `path` is a parameter and not a read of location.pathname because the caller is not
   * always allowed to read it — see the header comment. The latch is written ONLY when we
   * emit: it used to be written on every call, including calls that concluded nothing had
   * changed, so a single pre-commit read recorded the old path as "seen", the real
   * navigation produced no second emit, and every later route change was compared against
   * a path one navigation stale. The change was not delayed; it was lost.
   *
   * `search` rides along for the sort key above, under the same pre-commit rule: the
   * navigate handler passes the DESTINATION's search, never a read of location.
   */
  function emit(path = location.pathname, search = location.search) {
    const next = classify(path);
    const sort = sortParamOf(search);
    if (next === current && emit.lastPath === path && emit.lastSort === sort) return;
    current = next;
    emit.lastPath = path;
    emit.lastSort = sort;
    listeners.forEach(fn => { try { fn(current, path); } catch (e) { SHD.gate.reportError(e); } });
  }

  function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

  function start() {
    /* The bridge's history relay — the only route-change signal a browser without the
     * `navigation` API gets (Firefox ESR 140, the Firefox build floor, has none — the
     * API landed in 147; current Firefox release does). Patching history OURSELVES
     * here was the old fallback, and it is the classic realm mistake: a content
     * script's `history` binding is its own world's, Reddit's router calls the page
     * realm's, and under Firefox's realm separation the patch never fires — every SPA
     * navigation went unseen and only popstate worked. bridge.js patches the realm
     * Reddit actually calls and relays each commit as a bare event; by dispatch time
     * location already holds the NEW url, and the dispatch is synchronous inside
     * Reddit's own pushState call, so teardown still precedes the feed swap. Do not
     * reintroduce a same-realm patch: it masks a dead relay in every one-world test
     * environment while shipping broken. See docs/engineering-log.md bug 82.
     *
     * Registered even when the navigation API exists — emit() is idempotent per path,
     * so on Chrome this is one more post-commit safety net, same role as
     * navigatesuccess below. */
    addEventListener(SHD.C.BRIDGE.navigated, () => emit(location.pathname));
    addEventListener('popstate', () => emit(location.pathname));
    if (typeof navigation !== 'undefined' && navigation.addEventListener) {
      navigation.addEventListener('navigate', (e) => {
        // Deliberately NOT filtered on e.destination.sameDocument. Measured on live
        // Reddit: a sort-tab click reports sameDocument === false and then survives as a
        // same-document navigation anyway, because Reddit's router calls intercept() —
        // the flag describes the destination BEFORE interception, not what happens. A
        // guard here would skip exactly the navigations this listener exists for.
        //
        // Emitting on a genuine cross-document navigation is harmless: the document is
        // about to be replaced and the fresh boot re-emits from scratch.
        let path = null;
        let search = '';
        try {
          const u = new URL(e.destination.url);
          if (u.origin === location.origin) { path = u.pathname; search = u.search; }
        } catch { /* unparseable destination — navigatesuccess below still covers us */ }
        // Emit BEFORE the commit, so our teardown runs before Reddit swaps its feed in.
        // Emitting only after the swap lets the incoming posts be consumed and stamped
        // against the outgoing page — and a stamped post is never rendered again, which is
        // where "6 posts, no more pages" came from.
        if (path) emit(path, search);
      });
      // Post-commit safety net: redirects, destinations we could not parse, and anything
      // that reached the URL without a navigate event we understood. emit() is idempotent
      // per path, so this is free when the pre-commit emit already did the work.
      navigation.addEventListener('navigatesuccess', () => emit(location.pathname));
    }
    emit(location.pathname);
  }

  return { LISTING, COMMENTS, PROFILE, OTHER, SORTS, PROFILE_TABS, TIMES, TIMED_SORTS,
           RENDER_HOSTS, rendersHost,
           classify, subredditOf, sortOf, usernameOf, profileTabOf, onChange, start,
           get current() { return current; },
           get path() { return emitPath(); },
           /* The `?sort=` value this module last emitted for — the emitPath() rule
              applied to the query: anything decorating the render (the comments page's
              sort strip) must agree with the navigation that produced it, not with a
              location that is one commit behind or ahead. Empty string when the emitted
              URL carried none. Parsed out of the composite latch key rather than being
              the key itself, because the key now carries the time window too. */
           get sortQuery() {
             const m = /(?:^|&)sort=([^&]*)/.exec(emit.lastSort || '');
             return m ? m[1] : '';
           },
           /* The `?t=` window, same rule. '' when the URL carried none, which is Reddit's
              own default and NOT one of TIMES — see the strip in chrome.js. */
           get timeQuery() { return timeOf(); } };
})();

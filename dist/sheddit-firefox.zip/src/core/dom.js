/**
 * dom.js — minimal DOM builder + formatters. No dependencies, no innerHTML with data.
 */
globalThis.SHD = globalThis.SHD || {};

SHD.dom = (() => {
  /**
   * h('a.title', {href, target}, 'text' | node | [..])
   * Tag string supports .class and #id shorthand.
   */
  function h(tag, attrs, children) {
    const [name, ...rest] = tag.split(/(?=[.#])/);
    const el = document.createElement(name || 'div');

    for (const token of rest) {
      if (token[0] === '.') el.classList.add(token.slice(1));
      else if (token[0] === '#') el.id = token.slice(1);
    }

    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        if (k === 'class') { el.classList.add(...String(v).split(/\s+/).filter(Boolean)); }
        else if (k === 'text') { el.textContent = v; }
        else if (k.startsWith('on') && typeof v === 'function') { el.addEventListener(k.slice(2), v); }
        else if (k === 'dataset') { Object.assign(el.dataset, v); }
        else el.setAttribute(k, v === true ? '' : String(v));
      }
    }

    append(el, children);
    return el;
  }

  function append(el, children) {
    if (children == null) return;
    if (Array.isArray(children)) { children.forEach(c => append(el, c)); return; }
    el.appendChild(children instanceof Node ? children : document.createTextNode(String(children)));
  }

  /** 8364 -> "8364"; old reddit shows raw scores, but caps display width. */
  function score(n) {
    if (n == null || Number.isNaN(n)) return '•';
    return String(n);
  }

  /** ISO timestamp -> "6 hours ago" */
  function ago(iso) {
    const then = Date.parse(iso);
    if (Number.isNaN(then)) return '';
    const s = Math.max(1, Math.floor((Date.now() - then) / 1000));
    const units = [
      [31536000, 'year'], [2592000, 'month'], [604800, 'week'],
      [86400, 'day'], [3600, 'hour'], [60, 'minute'], [1, 'second']
    ];
    for (const [secs, label] of units) {
      if (s >= secs) {
        const n = Math.floor(s / secs);
        return `${n} ${label}${n === 1 ? '' : 's'} ago`;
      }
    }
    return 'just now';
  }

  /** "self.Layoffs" -> "self.Layoffs"; strips protocol from real domains. */
  function domain(d) { return (d || '').replace(/^www\./, ''); }

  function plural(n, word) { return `${n} ${word}${n === 1 ? '' : 's'}`; }

  /* ------------------------------------------------------------------ *
   * Cloned-body repair
   * ------------------------------------------------------------------ */

  /**
   * Swap a cloned body's <shreddit-player gif> for something that can show it — bugs 88, 93.
   *
   * Cloned comment and selftext bodies keep their custom elements, and custom-element
   * upgrade is DOCUMENT-global — so the clone in our layout comes alive as Reddit's own
   * player and inherits its defect wholesale: the gif variant feeds a raw `.gif` URL to
   * a <video> (which cannot decode GIF — readyState 0 on 8 of 8 captured live) and,
   * carrying no poster, paints a solid box where the picture should be. The picture is
   * sitting in the player's light-DOM <source> the whole time, and the comment GIFs that
   * already rendered fine on the same page were plain <img>s from the same host — so
   * degrade to that. A player with no resolvable source is left alone: an empty box beats
   * silently deleting content someone wrote a comment around.
   *
   * WHICH ELEMENT depends on what Reddit is actually serving, which is bug 93: the same
   * `.gif` name is delivered as a real GIF (`format=gif`) or as an mp4 (`format=mp4`,
   * `content-type: video/mp4`), and an <img> can show only the first. Putting the second
   * in an <img> is the blank box again wearing our own markup — so the mp4 delivery goes
   * into a <video> playing it the way a GIF plays: muted, looping, no controls, started
   * without being asked. C.GIF_MP4_SRC owns the discrimination and why it is the URL that
   * has to answer.
   *
   * SHD.C is read at CALL time, not load time — dom.js stays dependency-free at load,
   * and nothing calls this before boot.
   */
  function inlineGifs(root) {
    if (!root || !SHD.C || typeof root.querySelectorAll !== 'function') return root;
    root.querySelectorAll(SHD.C.GIF_PLAYER).forEach(p => {
      const source = p.querySelector('source');
      const src = source?.getAttribute('src') || p.getAttribute('src');
      if (!src) return;
      /* `type` when Reddit troubles to state one — it did not on any player captured, so
         the URL is what decides in practice and this is belt to that braces. */
      const mp4 = /^video\//i.test(source?.getAttribute('type') || '') ||
        SHD.C.GIF_MP4_SRC.test(src);
      p.replaceWith(mp4 ? gifVideo(src)
        : h('img.shd-comment-gif', { src, alt: '', loading: 'lazy' }));
    });
    return root;
  }

  /**
   * An mp4-delivered comment GIF, rendered as the GIF it is standing in for.
   *
   * No controls and no sound, because the thing it replaces has neither — a comment GIF
   * that arrives with a scrub bar reads as a video someone posted, which is not what was
   * posted. `preload="metadata"` is the one request worth making of a thread carrying
   * twenty of these: ask for the first frame, not the whole file. Autoplay then pulls
   * what it needs when the browser decides to start — Chrome defers an offscreen muted
   * autoplay until it scrolls into view, which is the moment the picture is wanted.
   *
   * The `muted` ATTRIBUTE is not enough on its own and the difference is the whole fix:
   * on an element built in script the attribute only seeds `defaultMuted` at CREATION,
   * so setting it afterwards leaves `muted` false — and Chrome's autoplay policy reads
   * the PROPERTY. An unmuted autoplaying video is blocked, and a blocked video is the
   * blank box we came here to remove. Both are set: the property for this element, the
   * attribute for anything that reads the markup back.
   */
  function gifVideo(src) {
    const video = h('video.shd-comment-gif', {
      src, autoplay: '', loop: '', muted: '', playsinline: '', preload: 'metadata'
    });
    video.muted = true;
    return video;
  }

  /**
   * Take a copy of one of Reddit's own rendered bodies, for use inside our layout.
   *
   * The clone is the right call and is not in question: it keeps links, code blocks,
   * blockquotes and spoilers intact with no markdown re-parse of our own. What it also
   * does is carry a subtree WE DID NOT AUTHOR across into a document we control, and a
   * cloned <script> loses its "already started" flag — so it executes on insertion.
   * Iframes, objects and embeds come alive the same way.
   *
   * Reddit sanitises what it renders, so this is defence in depth rather than a live
   * hole. It is here because the header of this file promises "no innerHTML with data"
   * as though the question were settled, and for someone else's subtree it is not.
   * Four tag names cost nothing and remove the whole class.
   */
  function adoptBody(node) {
    if (!node) return null;
    const copy = node.cloneNode(true);
    copy.querySelectorAll?.('script, iframe, object, embed').forEach(n => n.remove());
    return inlineGifs(copy);
  }

  /* ------------------------------------------------------------------ *
   * Shadow-piercing lookup
   * ------------------------------------------------------------------ */

  /**
   * querySelector that descends into OPEN shadow roots.
   *
   * Needed for vote delegation. The action bar hydrates inside a shreddit-async-loader,
   * and ARCHITECTURE §1.2 records that element as having a shadow root — so a plain
   * light-DOM querySelector may never find the native button no matter how long we wait.
   * A closed shadow root is unreachable by design; we return null and the caller reports.
   */
  function deepQuery(root, selector) {
    if (!root || typeof root.querySelector !== 'function') return null;
    const direct = root.querySelector(selector);
    if (direct) return direct;
    /* The ROOT'S OWN shadow root, first. This was missing for the whole life of the
       function: it searched the shadow roots of the root's DESCENDANTS and never the one on
       the element it was handed — and a custom element's own shadow root is exactly where
       that element renders its own UI. Measured 2026-09-05, logged in: 23 open shadow
       roots searched under a live shreddit-post, upvote control NOT FOUND, which is the
       same answer the logged-out runs gave and, with this gap, could not have been anything
       else if the action bar lives on the post's own root. Whether it does is what the next
       verify:live run reports (its VOTE DELEGATION section now dumps the host's own root). */
    if (root.shadowRoot) {
      const own = deepQuery(root.shadowRoot, selector);
      if (own) return own;
    }
    for (const el of root.querySelectorAll('*')) {
      if (!el.shadowRoot) continue;
      const hit = deepQuery(el.shadowRoot, selector);
      if (hit) return hit;
    }
    return null;
  }

  /** How many open shadow roots hang at or below `root`, its own included. Diagnostics only. */
  function shadowRoots(root) {
    if (!root || typeof root.querySelectorAll !== 'function') return 0;
    let n = root.shadowRoot ? 1 + shadowRoots(root.shadowRoot) : 0;
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) n += 1 + shadowRoots(el.shadowRoot);
    }
    return n;
  }

  /* ------------------------------------------------------------------ *
   * Native passthrough
   * ------------------------------------------------------------------ */

  const PASS = 'shd-passthrough';           // an ancestor on the path to the target
  const PASS_HIDE = 'shd-passthrough-hide'; // a sibling of that path
  const PASS_ROOT = 'shd-native-passthrough';
  const EXIT_ID = 'shd-passthrough-exit';

  /**
   * Reveal one native element in place, hiding everything else.
   *
   * suppress.css clips the DIRECT CHILD OF <body> (shreddit-app). clip-path and opacity
   * apply to the whole subtree, so tagging a deep descendant — which is what the first
   * cut did to the <shreddit-comment> — cannot un-hide it: the ancestor is still clipped
   * seven levels up.
   *
   * So we walk the path from the target to the body child, un-clip that body child, and
   * display:none every SIBLING along the way. Only the corridor down to the target
   * survives. #shd-root is hidden for the duration and restored by passthroughClear().
   */
  function passthrough(el) {
    passthroughClear();
    if (!el || !el.isConnected || el === document.body) return false;

    const chain = [];
    for (let n = el; n && n !== document.body; n = n.parentElement) chain.push(n);
    const top = chain[chain.length - 1];
    if (!top || top.parentElement !== document.body) return false;

    for (const n of chain) {
      n.classList.add(n === top ? PASS_ROOT : PASS);
      // Body-level siblings are already suppressed by the base rule, and hiding them
      // here would take #shd-root with them.
      if (n === top) continue;
      for (const sib of n.parentElement.children) {
        if (sib !== n) sib.classList.add(PASS_HIDE);
      }
    }

    document.documentElement.classList.add('shd-passthrough-active');
    document.body.appendChild(h('div#' + EXIT_ID, null,
      h('a', { href: '#', text: '← back to sheddit',
               onclick: (e) => { e.preventDefault(); passthroughClear(); } })));
    return true;
  }

  /** Undo passthrough() and put our own layout back. */
  /**
   * Put a sentence in the exit bar, which is the ONE surface of ours a reader can still
   * see once a handoff is up.
   *
   * passthrough() hides #shd-root, and the reply form — with its status line — is inside
   * it. So the sentence explaining where the reader's draft went, including the one that
   * literally reads "your text is still here, behind ← back to sheddit", was being written
   * onto the half of the page they had just been taken off. account.js's own comment two
   * functions up says "a message nobody can read is not a fallback"; that was written
   * about the draft and the same thing was true of the message about it.
   *
   * The bar is excluded from the suppression rule and fixed at the top of the viewport, so
   * it survives everything the handoff hides. Nothing here creates it: a note without a
   * bar to sit in has no reader either, so this reports false and the caller's own status
   * line stays the record.
   */
  function passthroughNote(text) {
    const bar = document.getElementById(EXIT_ID);
    if (!bar) return false;
    let note = bar.querySelector('.shd-passthrough-note');
    if (!note) note = bar.appendChild(h('span.shd-passthrough-note'));
    note.textContent = text;
    return true;
  }

  function passthroughClear() {
    for (const cls of [PASS, PASS_HIDE, PASS_ROOT]) {
      document.querySelectorAll('.' + cls).forEach(e => e.classList.remove(cls));
    }
    document.getElementById(EXIT_ID)?.remove();
    document.documentElement.classList.remove('shd-passthrough-active');
  }

  /**
   * The selector for a rendered row, with the id ESCAPED.
   *
   * Five call sites built this by interpolating a Reddit id straight into an attribute
   * selector. Reddit's ids are `t3_…`/`t1_…` and safe today, which is exactly what makes
   * this the kind of thing that stays broken: one `"` or `\` in an id — Reddit's choice,
   * not ours, and it can change without notice — turns the string into invalid CSS and
   * `querySelector` throws a SyntaxError. Inside flush() that lands in gate.reportError,
   * and eight of them spend the whole error budget and put the failure card over a page
   * that is fine.
   *
   * Escaping the two characters that can end a quoted CSS string is the whole fix, and
   * it is preferred to CSS.escape here: that function escapes for use as an IDENTIFIER,
   * so it also rewrites leading digits and spaces into hex escapes that are merely
   * verbose inside quotes. Backslash and double quote are the injection surface.
   */
  const rowSel = (id) =>
    `.thing[data-fullname="${String(id).replace(/["\\]/g, '\\$&')}"]`;

  return { h, score, ago, domain, plural, inlineGifs, adoptBody, rowSel,
           deepQuery, shadowRoots, passthrough, passthroughNote, passthroughClear };
})();

/**
 * account.js — the account layer: what changes for a reader who is ALREADY logged in.
 *
 * Vote, reply, post, and editing the reader's own comments. Nothing here holds a
 * session, calls an endpoint or builds a request. Every action is a click forwarded to
 * the control Reddit rendered for the same purpose, or text handed to Reddit's own editor
 * followed by a click on Reddit's own submit button — ARCHITECTURE §5's delegation tier,
 * extended from "the arrow" to "the reply box", with Reddit's page code still owning the
 * auth, the network request, the error handling and the optimistic insert. The extension
 * adds nothing to its network surface with this file in it.
 *
 * WHO THIS IS FOR, AND WHO IT MUST NOT TOUCH
 * SHD.session decides whether the layer is on (setting AND a logged-in page). For the
 * primary, logged-out reader every path in here collapses to 0.33.0's behaviour — arrows
 * that cast nothing, except that they now say why (see VOTING below: Reddit does ship its
 * vote buttons to a logged-out session, but with no vote state on them, and a click is
 * forwarded only when a button reports one or a session is recognised), a `reply` that
 * hands off to Reddit's own comment via passthrough, and no submit buttons. That is asserted, not assumed: test/run.js boots the same fixtures
 * logged out and checks nothing new appears.
 *
 * VOTING TRUSTS WHAT IT CAN VERIFY
 * A click resolves the native button at click time (the action bar hydrates late, §1.3).
 * It used to forward to whatever it found, on the rule that the button's presence IS
 * ground truth because Reddit renders it only for a session that can use one. That rule
 * is false now — Reddit ships vote buttons to logged-out readers too — and it produced a
 * fake vote: a score that moved, an arrow that lit, and no request behind either.
 *
 * The rule is now EITHER of two signals, because either one makes the vote answerable
 * for. A button exposing its own state (`aria-pressed`) lets settle() read the page's
 * verdict back and overrule our optimistic paint; a session the detector recognises means
 * the click has somewhere to land even if the state is not exposed yet. Neither, and the
 * click casts nothing and the row says why. The detector is still not trusted ALONE, which
 * is what keeps a logged-in reader with an unfamiliar header able to vote.
 *
 * "At click time" is not enough on its own for a comment, and this is the one place the
 * extension reaches into the page's own layout rather than only its DOM. Reddit mounts a
 * comment's action row — both `Reply` and its vote buttons — when the comment is near a
 * viewport, and nothing in this layout ever scrolls Reddit's copy of the thread. So a miss
 * scrolls the native row inside the box suppress.css leaves it and asks again (nudge(),
 * resolveLate()), and only a miss that survives that is reported as one.
 *
 * WHAT IS UNVERIFIED
 * The composer protocol (C.COMPOSER) and the per-comment reply control (C.NATIVE.reply)
 * were shaped from ordinary use of the site and first driven only against fixtures that
 * model them. Signed-in measurement since (2026-09-05 onward, see contracts.js and log
 * 111-113) has confirmed some of it and corrected more, and the reply control is still a
 * candidate — the measurement needs a desk, not a container (CONTRIBUTING). So every step measures its outcome and
 * every miss has the same floor: reveal Reddit's own composer in place with whatever text
 * did land, and let the reader finish in Reddit's UI. The reply the reader typed is never
 * discarded — the form stays, draft intact, until the reply is seen to arrive.
 */
globalThis.SHD = globalThis.SHD || {};

SHD.account = (() => {
  const { h, score, plural } = SHD.dom;
  const C = SHD.C;

  /* Mutable for the suite, like comments.timings — nothing in the extension writes it.
     syncMs: how long after render to look for a hydrated vote state (the bar is not there
             at first paint; 1.5s is the verify:live wait that found it hydrated).
     settleMs: how long after a forwarded click to re-read the native state, for a page
             that updates its button on the response rather than optimistically.
     composeWaitMs / pollMs: how long to wait for Reddit to mount its editor after the
             reply control is clicked.
     hydrateWaitMs: how long to wait for Reddit to mount a comment's action row after the
             row has been scrolled inside the suppressed tree's box (nudge()).
     reconcileMs: how long inserted text has to survive before it counts as landed. A rich
             editor reconciles its DOM against its own model a microtask or a frame after
             the write, and text that does not outlive that was never accepted (landed()).
     arriveWaitMs: how long to wait for the posted comment to appear before calling the
             submit lost and revealing the native composer.
     editRefreshMs: how long after the reader leaves an edit handoff to keep copying the
             comment's body into our row, for a save that lands after they pressed back.
     unreadPollMs: how often the header envelope re-reads Reddit's unread badge. */
  const timings = { syncMs: 1500, settleMs: 400, composeWaitMs: 4000, pollMs: 100, arriveWaitMs: 8000,
                    drawerWaitMs: 4000, logoutWaitMs: 6000, hydrateWaitMs: 3000,
                    reconcileMs: 120, editRefreshMs: 15000, unreadPollMs: 5000 };

  const active = () => SHD.session.active();
  let generation = 0;
  const drafts = new Map();
  const forms = new Map();
  const draftKey = (m, kind) => JSON.stringify([
    SHD.session.username(), kind,
    m.id || m.source.getAttribute(kind === 'post' ? C.POST_ATTR.id : C.COMMENT_ATTR.id)
  ]);

  /* ------------------------------------------------------------------ *
   * Vote
   * ------------------------------------------------------------------ */

  /* A miss is either "not hydrated yet" (retry works) or "contracts.js is stale" (retry
     never works). Warn ONCE, with the evidence needed to tell them apart — and only on a
     session where the control is expected. Logged out it is known not to exist. */
  let missWarned = false;
  function reportMiss(kind, m) {
    if (missWarned || !active()) return;
    missWarned = true;
    const loader = m.source.querySelector(C.ASYNC_LOADER);
    console.warn(
      `[sheddit] no ${kind} control found on ${m.id} (logged-in session). ` +
      `async-loader present: ${!!loader}; open shadow roots searched: ${SHD.dom.shadowRoots(m.source)}. ` +
      `If the action bar is visibly hydrated on the page, C.NATIVE.${kind} in contracts.js ` +
      `is stale, or the control sits in a CLOSED shadow root and cannot be delegated to.`);
  }

  /**
   * Say so on the row when the control still cannot be reached — the FLOOR, after the
   * click has already given Reddit the chance it was waiting for (see nudge()).
   *
   * Reported from a signed-in session: every comment vote was a silent no-op — arrow
   * dead, score still, nothing said — while post votes on the same page worked. That is
   * log 62's sin exactly ("a control that ignores a click is worse than no control"),
   * and reportMiss() only ever reached the console, once per page.
   *
   * WHY A COMMENT MISSES AND A POST DOES NOT. A post's vote buttons live in the POST'S OWN
   * open shadow root and need no hydration, so they are there whenever we look. A
   * comment's live one level down, inside the open shadow root of its lazily-hydrated
   * <shreddit-comment-action-row>, which Reddit mounts on viewport position — and THE
   * READER SCROLLS OUR ROWS, NEVER REDDIT'S, so that row is never near a viewport of its
   * own accord. That is the part the click now handles. What is left for this function is
   * everything else: hydration that did not finish inside the deadline, a stale contract,
   * or a control that moved into a closed root.
   *
   * TWO REASONS, because they are not the same news and the earlier copy gave the wrong
   * one to the reader most likely to see it. `unavailable` says the control has not
   * arrived \u2014 true on a signed-in page, and it invites another try. Said to a LOGGED-OUT
   * reader it is a straight falsehood: nothing is loading, and no amount of waiting will
   * produce a vote. That reader is this extension's primary audience, so they get
   * `logged-out` and a sentence that is actually about them.
   *
   * The mark is not permanent. clearUnavailable() takes it off the moment a control does
   * resolve, because a row that said "not yet" and then hydrates has to stop saying it.
   */
  const MISS_COPY = {
    'logged-out': 'You are not logged in to Reddit, so this arrow cannot cast a vote',
    comment: 'Reddit has not loaded this comment\u2019s vote control, so this arrow cannot do anything yet',
    post: 'Reddit has not loaded this post\u2019s vote control, so this arrow cannot do anything yet'
  };

  function markMiss(col, kind, reason = 'unavailable') {
    col.dataset.shdVoteMiss = reason;
    const why = reason === 'logged-out' ? MISS_COPY['logged-out'] : MISS_COPY[kind];
    for (const a of col.querySelectorAll('.arrow')) {
      a.setAttribute('title', why);
      a.setAttribute('aria-disabled', 'true');
    }
  }

  /** Undo markMiss(): the control turned up after all. */
  function clearUnavailable(col) {
    if (col.dataset.shdVoteMiss == null) return;
    delete col.dataset.shdVoteMiss;
    for (const a of col.querySelectorAll('.arrow')) {
      a.removeAttribute('title');
      a.removeAttribute('aria-disabled');
    }
  }

  /**
   * Bring a native node inside the suppressed tree's box, so Reddit's own observer can
   * see it and mount whatever it defers on viewport position.
   *
   * suppress.css gives each native body child the viewport's dimensions with its own
   * overflow clipped — which is what lets anything on the native tree hydrate at all —
   * but a row past that box's first screen is still clipped out of it, and nothing in this
   * layout ever scrolls Reddit's copy. This does, on the click that needs it, and only
   * then: walking the native tree into view once per rendered row would be a page's worth
   * of layout for a reader who may never vote.
   *
   * A vote that moved the reader's place in a thread would be worse than a vote that
   * misses, and the thing that prevents it is the suppression rule rather than anything
   * here: the box is `position: fixed`, so the document is not in the containing-block
   * chain scrollIntoView walks and cannot be scrolled by this call. That was written first
   * as a save-and-restore of window.scrollX/scrollY — measured against the packed
   * extension in Chromium, the restore never fired once, because there was never anything
   * to restore. It is gone, and the guarantee is asserted where it actually lives:
   * test/extension.js checks the reader's scroll position across a comment vote, and the
   * mutation row that puts the native tree back in flow fails that assertion.
   */
  function nudge(source) {
    try { source.scrollIntoView?.({ block: 'center' }); }
    catch { /* geometry is the bonus here, never the requirement */ }
  }

  /**
   * A control that was not there when we first looked: give Reddit the one thing it is
   * waiting for, and keep looking until the deadline. Resolves to the control or null.
   */
  function resolveLate(source, find, alive) {
    nudge(source);
    return waitFor(find, timings.hydrateWaitMs, alive);
  }

  /**
   * Reddit's vote buttons for THIS row. A post's are on its own shadow root. A comment's
   * are on its action row — and a <shreddit-comment> CONTAINS its replies, so a plain
   * deep search answers with the first hydrated row anywhere in the subtree. Measured
   * live, signed in, 2026-11-01: with the comment's own row not yet mounted and a reply's
   * row mounted, clicking up on the comment sent UpdateCommentVoteState for the reply, and
   * settle() then painted the comment from the reply's state. Only a button the comment
   * itself owns counts; none means "not hydrated yet", which resolveLate() handles.
   */
  function ownedButton(source, selector) {
    const scan = (root) => {
      for (const el of root.querySelectorAll(selector)) if (ownerComment(el) === source) return el;
      if (root.shadowRoot) { const hit = scan(root.shadowRoot); if (hit) return hit; }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot && ownerComment(el) === source) {
          const hit = scan(el.shadowRoot); if (hit) return hit;
        }
      }
      return null;
    };
    return source && typeof source.querySelectorAll === 'function' ? scan(source) : null;
  }

  const nativeButtons = (source, kind = 'post') => kind === 'comment'
    ? { up: ownedButton(source, C.NATIVE.upvote), down: ownedButton(source, C.NATIVE.downvote) }
    : { up: SHD.dom.deepQuery(source, C.NATIVE.upvote), down: SHD.dom.deepQuery(source, C.NATIVE.downvote) };

  /**
   * What Reddit's buttons say the reader's vote is: 1, -1, 0 — or null when neither
   * button carries the state attribute at all, in which case the arrows keep their own
   * local toggle and the page's buttons are never contradicted, only not mirrored.
   */
  function nativeState({ up, down }) {
    const u = up?.getAttribute(C.NATIVE.voteState);
    const d = down?.getAttribute(C.NATIVE.voteState);
    if (u == null && d == null) return null;
    if (u === 'true') return 1;
    if (d === 'true') return -1;
    return 0;
  }

  /** The element showing this row's score: the midcol's own on a post, the tagline's on a comment. */
  function scoreNode(col, kind) {
    if (kind === 'post') return col.querySelector('.score');
    return col.parentElement?.querySelector(':scope > .entry > .tagline > .score') || null;
  }

  /**
   * Paint a vote state onto our arrows — old reddit's classes (`likes`/`dislikes` on the
   * column, `upmod`/`downmod` on the arrow) — and move the score with it. The score Reddit
   * sent already INCLUDES the reader's standing vote, so the displayed number is
   * `score + (state − initial)`, where `initial` is the first state the native buttons
   * were seen in. Never adjusted for a hidden score: "score hidden" stays hidden.
   */
  function paint(col, m, kind, state) {
    const initial = Number(col.dataset.shdVoteInitial || 0);
    col.dataset.shdVote = String(state);
    col.classList.toggle('likes', state === 1);
    col.classList.toggle('dislikes', state === -1);
    col.classList.toggle('unvoted', state === 0);
    col.querySelector('.arrow.up')?.classList.toggle('upmod', state === 1);
    col.querySelector('.arrow.down')?.classList.toggle('downmod', state === -1);
    const node = scoreNode(col, kind);
    if (node && m.score != null && !m.scoreHidden) {
      const n = m.score + (state - initial);
      node.textContent = kind === 'post' ? score(n) : plural(n, 'point');
    }
  }

  /** Record the first native state seen as the one the delivered score already counts. */
  function learnInitial(col, m, kind, btns) {
    if (col.dataset.shdVoteInitial != null) return;
    const s = nativeState(btns);
    if (s === null) return;
    col.dataset.shdVoteInitial = String(s);
    paint(col, m, kind, s);
  }

  /** Re-read the native state after a click, so the page's answer wins over our guess. */
  function settle(col, m, kind, btns) {
    const s = nativeState(btns);
    if (s !== null) paint(col, m, kind, s);
  }

  /** Forward the click to the button we resolved, and mirror it on our own arrows. */
  function cast(col, m, kind, dir, btns) {
    clearUnavailable(col);
    learnInitial(col, m, kind, btns);
    (dir === 1 ? btns.up : btns.down).click();
    // Optimistic, like old reddit: clicking the lit arrow un-votes, the other one flips.
    const before = Number(col.dataset.shdVote || 0);
    paint(col, m, kind, before === dir ? 0 : dir);
    // Then defer to the page, now and once more after it has had time to answer.
    setTimeout(() => col.isConnected && settle(col, m, kind, btns), 0);
    setTimeout(() => col.isConnected && settle(col, m, kind, btns), timings.settleMs);
  }

  /**
   * Can a click on this column become a real vote?
   *
   * THE BUTTON'S PRESENCE USED TO BE THE ANSWER AND NO LONGER IS. This file's header
   * argued that Reddit renders a vote control only for a session that can use one, so the
   * control was ground truth and the session detector was only consulted about what a MISS
   * meant (ARCHITECTURE §7d: "not reachable at all"). Reported from a logged-out session on
   * a live listing, and it is the worst kind of bug this code can have: clicking a post's
   * up arrow moved the score 5411 -> 5412 and lit `.upmod`, with no request made and no
   * login prompt. Reddit now ships those buttons to everyone.
   *
   * The optimistic paint could not be corrected either, which is what made it stick. It is
   * settle() that normally lets the page overrule our guess — but it reads `aria-pressed`,
   * and buttons served to a logged-out reader carry no state at all, so nativeState()
   * returns null, settle() returns without repainting, and the invented number stays on
   * screen until the page is reloaded. A vote the reader never cast, shown as cast, and
   * guaranteed to disagree with the real score.
   *
   * So the test is now EITHER signal, not the button alone: a readable native state (which
   * is the page telling us where the vote stands, and the thing settle() needs to be able
   * to correct us) or a session the detector recognises. Keeping the second clause is what
   * stops this from becoming the opposite bug — a logged-in reader whose header shape we
   * fail to recognise can still vote, which was the whole reason for distrusting the
   * detector in the first place.
   */
  const votable = (btns) => nativeState(btns) !== null || active();

  function vote(col, m, kind, dir) {
    const btns = nativeButtons(m.source, kind);
    if (dir === 1 ? btns.up : btns.down) {
      if (votable(btns)) return cast(col, m, kind, dir, btns);
      /* Reddit's button is right there and pressing it achieves nothing: logged out it
         opens a login prompt, which is a body child and therefore suppressed, so the
         reader would see precisely nothing happen. Say so instead of forwarding into
         silence — and never paint, because there is no vote to paint. */
      return markMiss(col, kind, 'logged-out');
    }
    /* No button at all. Logged out that is the end of it — the answer is known and no
       amount of hydration changes it, so do not spend a deadline finding out. */
    if (!active()) return markMiss(col, kind, 'logged-out');
    /* Signed in, this is the expected FIRST answer on a comment rather than the final
       one: Reddit has not mounted the action row that holds the button. Bring the native
       row into view, wait for it, and only then call it unavailable. The wait is kept to
       one at a time — a reader clicking a dead arrow twice should not start a second
       deadline, and the first one is already doing the work. */
    if (col.dataset.shdVoteWait) return;
    col.dataset.shdVoteWait = '1';
    resolveLate(m.source, () => {
      const late = nativeButtons(m.source, kind);
      return (dir === 1 ? late.up : late.down) ? late : null;
    }).then((late) => {
      delete col.dataset.shdVoteWait;
      if (!col.isConnected) return;
      if (late) return cast(col, m, kind, dir, late);
      reportMiss(dir === 1 ? 'upvote' : 'downvote', m);
      markMiss(col, kind);
    });
  }

  /**
   * The vote column for a post row (arrows around the score) or a comment (arrows only —
   * old reddit puts a comment's score in its tagline). Clicks delegate; see the header.
   * On an active session the column also looks for the hydrated state once, after
   * render, so a post the reader already voted on comes up lit.
   *
   * A COMMENT's state lives on its action row, which Reddit mounts only once the native
   * comment has been on screen — so it is read as our row scrolls into view rather than
   * all at once: an IntersectionObserver queues each visible comment, and the queue brings
   * ONE native comment into view at a time (nudge(), inside the suppressed fixed box, so
   * the reader's page does not move) and reads its buttons when they hydrate. Reported
   * from a signed-in session: comments the reader had already voted on came up unlit, and
   * the earlier approach of learning the state on the click left them unlit until then.
   */
  function midcol(m, kind = 'post') {
    const arrow = (dir, label) => {
      const el = h(`div.arrow.${dir === 1 ? 'up' : 'down'}`, {
        role: 'button', tabindex: '0', 'aria-label': label,
        onclick: (e) => { e.preventDefault(); vote(col, m, kind, dir); }
      });
      // A div playing a button answers to the keys a real one would.
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); vote(col, m, kind, dir); }
      });
      return el;
    };
    const col = h('div.midcol.unvoted', { dataset: { shdVote: '0' } }, [
      arrow(1, 'upvote'),
      kind === 'post'
        ? h('div.score.unvoted', {
            text: score(m.score),
            title: m.upvoteRatio != null ? `${Math.round(m.upvoteRatio * 100)}% upvoted` : null
          })
        : null,
      arrow(-1, 'downvote')
    ]);
    if (active()) {
      setTimeout(() => {
        if (col.isConnected) learnInitial(col, m, kind, nativeButtons(m.source, kind));
      }, timings.syncMs);
      if (kind === 'comment') watchCommentVote(col, m);
    }
    return col;
  }

  /* The comment-vote reading queue midcol() feeds. One job at a time: each one may scroll
     the native tree, and two at once would fight over where it is scrolled to. */
  let voteSync = null;
  function watchCommentVote(col, m) {
    if (typeof IntersectionObserver !== 'function') return;
    if (!voteSync) {
      const jobs = new WeakMap();
      const queue = [];
      let busy = false;
      const drain = async () => {
        if (busy) return;
        busy = true;
        const mine = voteSync;
        while (queue.length && voteSync === mine) {
          const [c, cm] = queue.shift();
          try { await readCommentVote(c, cm); } catch (err) { SHD.gate.reportError(err); }
        }
        busy = false;
      };
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          io.unobserve(e.target);
          const job = jobs.get(e.target);
          if (job) queue.push(job);
        }
        drain();
      }, { rootMargin: '200px 0px' });
      voteSync = { io, jobs, queue };
    }
    voteSync.jobs.set(col, [col, m]);
    voteSync.io.observe(col);
  }

  async function readCommentVote(col, m) {
    if (!col.isConnected || col.dataset.shdVoteInitial != null || !m.source?.isConnected) return;
    const read = () => {
      const btns = nativeButtons(m.source, 'comment');
      return nativeState(btns) === null ? null : btns;
    };
    let btns = read();
    if (!btns) {
      /* Never scroll the native tree while the reader is looking at it (a handoff): try
         again when the row is next on screen. */
      if (document.documentElement.classList.contains('shd-passthrough-active')) {
        voteSync?.io.observe(col);
        return;
      }
      nudge(m.source);
      btns = await waitFor(read, timings.hydrateWaitMs, () => col.isConnected);
    }
    if (btns && col.isConnected) learnInitial(col, m, 'comment', btns);
  }

  /* ------------------------------------------------------------------ *
   * Reply — drive Reddit's composer
   * ------------------------------------------------------------------ */

  /** Poll `cond` until it answers, `ms` runs out, or `alive` (optional) says to give up. */
  function waitFor(cond, ms, alive) {
    const deadline = Date.now() + ms;
    return new Promise((resolve) => {
      const tick = () => {
        if (alive && !alive()) return resolve(null);
        let v = null;
        try { v = cond(); } catch { v = null; }
        if (v) return resolve(v);
        if (Date.now() >= deadline) return resolve(null);
        setTimeout(tick, timings.pollMs);
      };
      tick();
    });
  }

  /**
   * Reddit's composer for THIS target. A comment's composer is looked for inside the
   * comment and scoped to it (a comment's subtree holds its descendants — §1.4's body
   * lesson applies to composers too); the post's is any composer that is not inside a
   * comment. `except` is a snapshot from before the reply control was clicked, so a
   * composer that was already open elsewhere is never mistaken for the one we asked for.
   */
  function findHost(target, kind, except = new Set()) {
    /* The post's composer is looked for inside the page's main column, not the whole
       document: the host list has a broad fallback clause, and a form elsewhere on the page
       whose action happens to mention comments must not become where the reader's comment
       goes (security review, 2026-09-05). */
    const scope = kind === 'comment' ? target : (document.querySelector(C.MAIN) || document);
    const all = [...scope.querySelectorAll(C.COMPOSER.host)];
    /* Reddit keeps a hidden EDIT composer inside each of the reader's own comments (and a
       loader around it). It is not a reply box; taking it as one skipped the Reply click
       and waited on a box that never opens — measured live, every reply to one's own
       comment ended at `composer`. */
    const edit = C.NATIVE.commentEditHost;
    const mine = all.filter(el => !except.has(el) &&
      !el.closest(edit) && !el.querySelector(edit) && (kind === 'comment'
      ? el.closest(C.COMMENT) === target
      : !el.closest(C.COMMENT)));
    return mine[0] || null;
  }

  const hostsNow = () => new Set(document.querySelectorAll(C.COMPOSER.host));

  /**
   * The comment a node belongs to, THROUGH shadow roots. `closest()` stops at a shadow
   * boundary and answers null for a button inside an action row's root — which is where
   * the vote buttons live and where a named reply control would — so an ownership test
   * built on closest() alone disowns exactly the controls it exists to find (it did:
   * twelve assertions red at once). Climb out of each root to its host and ask again.
   */
  function ownerComment(node) {
    for (let n = node; n;) {
      const c = typeof n.closest === 'function' ? n.closest(C.COMMENT) : null;
      if (c) return c;
      const root = typeof n.getRootNode === 'function' ? n.getRootNode() : null;
      n = root && root.host ? root.host : null;
    }
    return null;
  }

  /**
   * Reddit's reply control for THIS comment. The attribute clauses first (C.NATIVE.reply),
   * then the shape measured live 2026-09-05: a bare light-DOM <button> whose only handle
   * is its text, "Reply" (C.NATIVE.replyText). Every button reachable through the comment
   * — light DOM and open shadow roots — is a candidate, and only one the comment itself
   * owns counts: a comment's subtree holds its descendants' reply buttons as surely as it
   * holds their bodies (§1.4), and clicking a child's control would open a composer under
   * the wrong comment.
   */
  function replyControl(target) {
    const byAttr = SHD.dom.deepQuery(target, C.NATIVE.reply);
    if (byAttr && ownerComment(byAttr) === target) return byAttr;
    const owned = (b) => ownerComment(b) === target && C.NATIVE.replyText.test((b.textContent || '').trim());
    const scan = (root, depth) => {
      if (!root || depth > 8 || typeof root.querySelectorAll !== 'function') return null;
      for (const b of root.querySelectorAll('button')) if (owned(b)) return b;
      if (root.shadowRoot) { const hit = scan(root.shadowRoot, depth + 1); if (hit) return hit; }
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot && ownerComment(el) === target) {
          const hit = scan(el.shadowRoot, depth + 1); if (hit) return hit;
        }
      }
      return null;
    };
    return scan(target, 0);
  }

  /** Only the reader's direct replies to this target can confirm a submission. */
  function commentsUnder(target, kind) {
    const me = SHD.session.username && SHD.session.username();
    const mine = (n) => !!me &&
      (n.getAttribute(C.COMMENT_ATTR.author) || '').toLowerCase() === me.toLowerCase();
    const pool = kind === 'comment'
      ? [...target.querySelectorAll(C.COMMENT)]
      : [...document.querySelectorAll(`${C.COMMENT_TREE} ${C.COMMENT}`)];
    return pool.filter(n => mine(n) && (kind === 'comment'
      ? n.parentElement?.closest(C.COMMENT) === target
      : !n.parentElement?.closest(C.COMMENT) &&
        n.getAttribute(C.COMMENT_ATTR.depth) === '0' &&
        n.getAttribute(C.COMMENT_ATTR.postId) === target.getAttribute(C.POST_ATTR.id)));
  }

  /**
   * Put text into Reddit's editor so that Reddit's editor knows about it. A textarea is a
   * value and an input event. A contenteditable is fed through the browser's own editing
   * command first, because that is what produces the beforeinput/input sequence a
   * rich-text editor listens for. Direct DOM writes are a fallback only for plain
   * contenteditables: Lexical's DOM is not its submission model.
   */
  /**
   * DID IT LAND, AND DID IT STAY? The second half is not pedantry.
   *
   * A rich-text editor owns its DOM and reconciles it against its own model. Writing
   * `textContent` into one puts the words on screen for a moment and then the editor
   * removes them again — measured on a live thread, where two <p> nodes appeared in
   * Reddit's editor and were gone by the next frame. The old check read `textContent`
   * SYNCHRONOUSLY, one line after writing it, which is inside that moment: it returned
   * true for text that no longer existed by the time anything used the answer.
   *
   * What that bought was the worst outcome available here. compose() takes a true from
   * insertText() as permission to press Reddit's submit — so a false positive posts an
   * EMPTY comment under the reader's name, and the draft they typed goes nowhere. Every
   * other failure in this file leaves the reader's words in our form and says so; this one
   * would have spent their comment on nothing.
   *
   * So the answer is given a turn of the event loop to be wrong in. The editor's own
   * reconciliation is a microtask or a frame away; anything that survives this is text the
   * editor has accepted rather than text that is briefly in its DOM.
   */
  /**
   * WHITESPACE IS NOT PART OF THE COMPARISON, and the reason is structural, not cosmetic.
   * A rich editor renders a paragraph break as a second <p>, not as a newline character —
   * so an editor holding a two-paragraph draft perfectly has a textContent with no "\n" in
   * it at all, and a comparison against the raw draft can never match. Measured live:
   * every multi-line draft was reported as not landing, however well it had landed, which
   * sent the chain into the handoff and wrote the text a SECOND time.
   *
   * ALL whitespace goes, not just runs of it, and that is the part collapsing gets wrong:
   * two adjacent <p> nodes concatenate in textContent with NO separator between them —
   * `<p>reply.</p><p>Second</p>` reads "reply.Second" — so the draft's space at the
   * paragraph break has no counterpart on the editor's side to normalise to. What is left
   * once whitespace is gone must equal the draft, not merely contain it: changed retries
   * previously accumulated older versions and still passed this check.
   */
  const norm = (s) => String(s || '').replace(/\s+/g, '');
  const holds = (editor, text) => norm(editor.textContent) === norm(text);

  async function landed(editor, text) {
    if (!holds(editor, text)) return false;
    await new Promise(r => setTimeout(r, timings.reconcileMs));
    return holds(editor, text);
  }

  /**
   * Is this element something the reader could see? Null-safe, and returns the element so
   * it can sit directly inside a waitFor().
   *
   * Layout is the honest answer — a display:none ancestor anywhere, through any shadow
   * root, zeroes the client rects — and it is not defeated by our own suppression, which
   * hides the native tree with visibility and opacity rather than by removing its boxes.
   * jsdom does no layout at all, so every element reads as unseen there; on a page with no
   * layout engine the `hidden` attribute is the fallback, which is exactly what the
   * fixtures model and nothing a live page relies on.
   */
  const layoutless = () => !document.body || document.body.getClientRects().length === 0;
  function shown(el) {
    if (!el || !el.isConnected) return null;
    if (layoutless()) return el.closest?.('[hidden]') ? null : el;
    return el.getClientRects().length > 0 ? el : null;
  }

  /**
   * Open a collapsed composer the way the live page accepts: focus, not a click.
   * Measured on the top-level "Join the conversation" box — the trigger's own click does
   * nothing and a full synthetic pointer sequence did nothing (log 111), but focusing the
   * textarea inside the trigger's shadow root expands it in ~300ms, and the host exposes a
   * focus() of its own. Both are tried; neither is trusted, which is why the caller then
   * WAITS for a visible submit control rather than assuming. A composer that is already
   * open has no visible trigger and this is a no-op.
   *
   * THE FIRST TRIGGER IS NOT THE ONE ON SCREEN. findHost() can return the outer
   * shreddit-async-loader, whose light DOM keeps a placeholder trigger that is never
   * slotted — so the first match has no box, and this used to stop there without trying
   * anything (measured live, signed in, 2026-10-25: every top-level save reported
   * `composer`). The visible trigger is taken instead, and the composer host that owns it
   * is focused as well as the one we were handed: focusing comment-composer-host is what
   * opened the live box; focusing the loader does nothing.
   */
  function openComposer(host) {
    const trigger = deepAll(host, C.COMPOSER.trigger).find(shown);
    if (!trigger) return false;
    const owner = trigger.parentElement?.closest(C.COMPOSER.host);
    const editing = trigger.classList.contains('shd-native-editing');
    trigger.classList.add('shd-native-editing');
    try {
      try { trigger.shadowRoot?.querySelector('textarea')?.focus(); } catch { /* best effort */ }
      for (const el of new Set([owner, host])) {
        try { if (typeof el?.focus === 'function') el.focus(); } catch { /* best effort */ }
      }
    } finally {
      if (!editing) trigger.classList.remove('shd-native-editing');
    }
    return true;
  }

  /** Every match under `root`, through open shadow roots, in document order. */
  function deepAll(root, selector) {
    const out = [];
    const walk = (r) => {
      out.push(...r.querySelectorAll(selector));
      if (r.shadowRoot) walk(r.shadowRoot);
      for (const el of r.querySelectorAll('*')) if (el.shadowRoot) walk(el.shadowRoot);
    };
    if (root && typeof root.querySelectorAll === 'function') walk(root);
    return out;
  }

  /** The visible markdown textarea in this composer, if Reddit has swapped it in. */
  const markdownField = (host) => deepAll(host, C.COMPOSER.markdownHost)
    .map(el => el.shadowRoot?.querySelector('textarea') || el.querySelector('textarea'))
    .find(shown) || null;

  /**
   * The text field the reader would type into: the markdown textarea when it is showing,
   * otherwise the first VISIBLE editor. Not the first match — in markdown mode the rich
   * editor is still in the light DOM, hidden, and matches C.COMPOSER.editor first.
   */
  const editorOf = (host) => markdownField(host) || deepAll(host, C.COMPOSER.editor).find(shown) || null;

  /**
   * Our box is old reddit's, so its text is markdown. Reddit's rich editor would post it
   * as literal characters (`mode=richText`), so ask for its markdown editor first. A miss
   * leaves the rich editor in place, which is the old behaviour rather than a failure.
   */
  async function useMarkdown(host, alive) {
    if (markdownField(host)) return true;
    const toggle = deepAll(host, C.COMPOSER.toMarkdown)[0];
    if (!toggle) return false;
    toggle.click();
    return !!await waitFor(() => markdownField(host), timings.composeWaitMs, alive);
  }

  /**
   * Text as it reads once Reddit has rendered it, near enough to recognise a draft:
   * whitespace gone (see norm()), a link's destination gone, and the markdown punctuation
   * that renders as formatting rather than characters gone. Applied to both sides.
   */
  const plain = (s) => norm(String(s || '')
    .replace(/\]\([^)]*\)/g, ']')
    .replace(/[*_~`>#[\]\\^|]/g, ''));

  function matchesDraft(body, draft) {
    const rendered = plain(body.textContent);
    return rendered === plain(draft) || (!!body.querySelector('li') &&
      rendered === plain(draft.replace(/^[ \t]*(?:[-+*]|\d+[.)])[ \t]+/gm, '')));
  }

  /** The focused element THROUGH shadow roots — activeElement stops at each host. */
  function deepActive() {
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }

  async function insertText(editor, text, alive = () => true) {
    if (!alive()) return false;
    const activeBefore = deepActive();
    const editing = editor.classList.contains('shd-native-editing');
    editor.classList.add('shd-native-editing');
    try {
      if (typeof editor.focus === 'function') editor.focus();
      if (!alive()) return false;
      const tag = editor.tagName;
      if (tag === 'TEXTAREA' || tag === 'INPUT') {
        /* No reconciliation to outlive: a form control's value is the model, so what we
           wrote is what is there. Checked immediately and synchronously, as before. */
        editor.value = text;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        return editor.value === text;
      }
      /* NEVER BLIND. execCommand('insertText') writes wherever the caret is, and the
         focus() call above is a request rather than a guarantee — Reddit's editor did not
         take it. Measured live, twice: the reader's OWN draft box went from 478 to 956
         characters, then 375 to 750, exactly doubled, because the caret was still in
         .shd-reply-text when the command fired. That is not a failed insert; it is the
         extension corrupting the one copy of the text the reader was relying on. So the
         command runs only when the editor is verifiably the focused element, through any
         shadow root it sits in, and otherwise the write goes straight to the fallback,
         which addresses the editor by reference and cannot land anywhere else. */
      let done = false;
      if (deepActive() === editor && typeof document.execCommand === 'function') {
        /* ONE PARAGRAPH AT A TIME. execCommand('insertText') hands the editor a run of
           characters, and a newline inside that run is not a paragraph to a rich editor —
           measured live, a two-paragraph draft went in as one. 'insertParagraph' through
           execCommand is swallowed too; what the editor honours is the `beforeinput` a real
           Enter produces. So the draft is split where the reader left a blank line, each
           piece is typed, and between pieces the editor is told a paragraph ended the way
           the keyboard would tell it. */
        try {
          const root = editor.getRootNode();
          const selection = typeof root.getSelection === 'function'
            ? root.getSelection() : document.getSelection();
          if (!selection) return false;
          const range = document.createRange();
          range.selectNodeContents(editor);
          selection.removeAllRanges();
          selection.addRange(range);
          /* LEXICAL READS THE SELECTION FROM `selectionchange`, WHICH IS ASYNC. Typed
             before that event lands, a fresh editor has no selection of its own and drops
             the edit — measured against real Lexical in Chromium: execCommand returned
             true and nothing was ever inserted. One macrotask lets the event through. */
          await new Promise(r => setTimeout(r, 0));
          done = true;
          const paragraphs = text.split(/\n\s*\n/);
          for (const [i, para] of paragraphs.entries()) {
            if (!alive() || deepActive() !== editor) { done = false; break; }
            if (i && typeof InputEvent === 'function') {
              editor.dispatchEvent(new InputEvent('beforeinput',
                { inputType: 'insertParagraph', bubbles: true, cancelable: true }));
            }
            if (!alive() || deepActive() !== editor ||
                (para && document.execCommand('insertText', false, para) !== true)) {
              done = false;
              break;
            }
          }
        } catch { done = false; }
        /* AND IT WRITES ITS DOM LATER. Lexical takes the edit from the input event, reverts
           the browser's write, and renders its own model in a microtask — so straight after
           execCommand the editor reads EMPTY even though the edit was accepted. Checked synchronously, every
           Lexical insert looked failed, took the refusal below, and sent a reply whose
           text was already in Reddit's box into the handoff: the "press post twice" bug. */
        if (done) await new Promise(r => setTimeout(r, 0));
      }
      /* Plain contenteditables accept a value by reference. Lexical must accept the
         browser edit instead; leaving plausible DOM text behind could conceal failure. */
      if (!done || !holds(editor, text)) {
        if (!alive()) return false;
        // Lexical's DOM is not its model; a direct write must never authorize a submit.
        if (editor.matches(C.COMPOSER.richEditor)) return false;
        editor.textContent = text;
        const ev = typeof InputEvent === 'function'
          ? new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })
          : new Event('input', { bubbles: true });
        editor.dispatchEvent(ev);
      }
      return await landed(editor, text);
    } catch { return false; }
    finally {
      const restoreFocus = deepActive() === editor;
      if (!editing) editor.classList.remove('shd-native-editing');
      if (restoreFocus && activeBefore && activeBefore !== editor && activeBefore.isConnected) {
        activeBefore.focus?.();
      }
    }
  }

  /**
   * The protocol. Returns { ok, step, host }: `step` names the first thing that could
   * not be found or did not happen, `host` is the composer to reveal on the way out.
   */
  async function compose(target, text, kind, { alive = () => true, onSubmit = () => {} } = {}) {
    const epoch = generation;
    const live = () => epoch === generation && target.isConnected && active() && alive();
    const cancelled = () => ({ ok: false, step: 'cancelled', host: null });
    if (!live()) return cancelled();
    let host = findHost(target, kind);
    if (!host) {
      if (kind !== 'comment') return { ok: false, step: 'composer', host: null };
      /* `Reply` shares the lazily-hydrated action row with the vote buttons, so it misses
         for the same reason and takes the same answer: bring the native comment into the
         suppressed tree's box and look again. This is the step that used to fail on a real
         thread and send the reader to Reddit's own page with an empty box. */
      const btn = replyControl(target) || await resolveLate(target, () => replyControl(target), live);
      if (!live()) return cancelled();
      if (!btn) return { ok: false, step: 'reply-control', host: null };
      // Snapshotted after the wait, so a host that appeared during hydration is not
      // mistaken for one that was already open before we asked for anything.
      const before = hostsNow();
      btn.click();
      host = await waitFor(() => findHost(target, kind, before) || findHost(target, kind),
        timings.composeWaitMs, live);
      if (!live()) return cancelled();
      if (!host) return { ok: false, step: 'composer', host: null };
    }
    /* A COMPOSER THAT HAS NOT OPENED IS NOT A COMPOSER, and from a selector's side of the
       glass it looks exactly like one.
       Reddit ships the top-level composer COLLAPSED — a "Join the conversation" box whose
       rich editor has not been mounted. The dormant `[contenteditable]` inside it still
       matches C.COMPOSER.editor, so the editor lookup below used to succeed, and every
       failure was then attributed to `insert`: the one step that had in fact done nothing
       wrong got the blame, while the step that had actually failed reported success.
       Measured on a live thread; the reader saw "could not put the text into Reddit's
       reply box" for a box that was never open.
       The submit control is the discriminator, and a measured one: a collapsed composer
       has none, and one opened by a real click has both. Asked here, BEFORE the editor, so
       `composer` is what a collapsed box reports — which is also the step whose fallback is
       the right one, since there is nothing to type into. */
    /* AND OPEN MEANS VISIBLE, NOT PRESENT. The paragraph above was written on a
       measurement in which a collapsed box had no submit control at all. Measured again a
       week later, it has one — hidden, enabled, inside a hidden faceplate-form beside a
       hidden editor — so the presence test passed on a closed box and the insert went into
       an editor with no model (log 113). What a collapsed box shows instead is its
       trigger, and what opens it is focus on the textarea in the trigger's shadow root.
       So: if the trigger is the visible thing, open it; then wait for a submit control the
       reader could see, which is the one discriminator the markup has not moved under. */
    /* A HIDDEN COMPOSER DOES NOT SUBMIT. Measured live, signed in, 2026-10-25: the same
       script click on Reddit's Comment button posts when the composer is visible and does
       nothing at all — no request — under suppression's `visibility: hidden`, even seconds
       after the text landed. Visible is enough: still opacity 0 and pointer-events none
       from the suppressed body child, so the reader sees nothing and stays on our layout.
       Held from opening through arrival, since Reddit's submit finishes asynchronously. */
    const unhidden = !host.classList.contains('shd-native-editing');
    host.classList.add('shd-native-editing');
    try {
      if (!live()) return cancelled();
      openComposer(host);
      const opened = await waitFor(
        () => shown(SHD.dom.deepQuery(host, C.COMPOSER.submit)), timings.composeWaitMs, live);
      if (!live()) return cancelled();
      if (!opened) return { ok: false, step: 'composer', host };
      await useMarkdown(host, live);
      if (!live()) return cancelled();
      const editor = await waitFor(() => editorOf(host), timings.composeWaitMs, live);
      if (!live()) return cancelled();
      if (!editor) return { ok: false, step: 'editor', host };
      const inserted = await insertText(editor, text, live);
      if (!live()) return cancelled();
      if (!inserted) return { ok: false, step: 'insert', host };
      // Re-resolved rather than reusing `opened`: an editor that has just taken its first
      // text is exactly when a composer swaps a disabled button for a live one.
      const submit = SHD.dom.deepQuery(host, C.COMPOSER.submit) || opened;
      const seen = new Set([...document.querySelectorAll(C.COMMENT)]
        .map(n => n.getAttribute(C.COMMENT_ATTR.id)));
      const alerts = new Set(document.querySelectorAll(C.COMPOSER.error));
      const sentAt = Date.now();
      if (!live()) return cancelled();
      onSubmit();
      if (!live()) return cancelled();
      submit.click();
      /* ONLY A COMMENT THAT APPEARED COUNTS AS POSTED. Nothing weaker.
         This used to accept two other signals as well — the composer disappearing, or the
         editor reading empty — on the reasoning that both are what Reddit does once a post
         succeeds. They are. They are also exactly what an editor looks like when the insert
         never took: measured live, a single-line draft passed landed(), submit was pressed
         on an editor Reddit had no model for, Reddit posted nothing, and the editor then
         read empty BECAUSE nothing had ever been accepted into it. That emptiness was taken
         as arrival. The form closed on it and the draft went with it — the one failure this
         file promises never to produce, reached by way of the check meant to prevent it.
         An editor that was never filled is indistinguishable from one Reddit cleared after
         a successful post, so neither can carry the arrival signal. A new, recent comment
         by this reader under the right parent with matching text can. Ambiguous arrivals
         go the safe way: `arrival`, thread and draft kept, and a sentence saying to check
         the thread before sending it again. */
      /* A REJECTION IS AN ANSWER TOO. Reddit refuses a submit (rate limit, locked thread)
         with an error alert instead of a comment; waiting the arrival deadline out on that
         told the reader their reply "may already have posted" when Reddit had said plainly
         that it had not. A new alert ends the wait with Reddit's own words. */
      const outcome = await waitFor(() => {
        const rejected = [...document.querySelectorAll(C.COMPOSER.error)].find(a => !alerts.has(a));
        if (rejected) return { rejected };
        const comment = commentsUnder(target, kind).find(n => {
          const id = n.getAttribute(C.COMMENT_ATTR.id);
          const body = [...n.querySelectorAll(C.COMMENT_BODY)].find(b => b.closest(C.COMMENT) === n);
          return id && !seen.has(id) &&
            Date.parse(n.getAttribute(C.COMMENT_ATTR.created)) >= sentAt - 2000 &&
            body && matchesDraft(body, text);
        });
        return comment ? { comment } : null;
      }, timings.arriveWaitMs, live);
      if (!live()) return cancelled();
      if (outcome?.rejected) {
        return { ok: false, step: 'rejected', host, message: outcome.rejected.getAttribute('message') };
      }
      return outcome ? { ok: true, step: 'done', host } : { ok: false, step: 'arrival', host };
    } finally {
      if (unhidden) host.classList.remove('shd-native-editing');
    }
  }

  /**
   * The handoff, after compose() has missed. Reveals Reddit's own UI and CARRIES THE
   * DRAFT INTO IT, which is the difference between a fallback and a dead end.
   *
   * Reported from a signed-in session: `save` on a real thread failed at `reply-control`,
   * the layout swapped to Reddit's comment, and its composer opened EMPTY — the reader
   * retyped their reply there. Our form kept the draft and said so, but passthrough hides
   * #shd-root, so both the text and the sentence promising it were on the side of the page
   * the reader had just been taken off. A message nobody can read is not a fallback.
   *
   * Why re-running the chain can work when the first attempt did not. The control this
   * misses on is usually `Reply`, inside the lazily-hydrated
   * <shreddit-comment-action-row>; compose() already scrolls the native comment into the
   * suppressed tree's box and waits for that row, so by the time anything reaches here the
   * cheap answer has been tried. passthrough() is the expensive one: it takes the body
   * child out of suppression altogether — full size, in flow, visible, hit-testable — which
   * is a different set of conditions from a clipped fixed box, and a row Reddit declined
   * to mount in the second can still mount in the first. It is also the only version of
   * this that puts the reader in front of Reddit's own UI, which is the actual promise:
   * finish the reply somewhere, with your words already in the box.
   *
   * Never the submit: this hands the reader Reddit's box with their words in it and stops.
   * Posting stays a deliberate press of Reddit's own button.
   */
  async function handoff(target, kind, text, r, alive = () => true) {
    if (!alive()) return false;
    const reveal = r.host || (kind === 'comment' ? target : document.querySelector(C.MAIN));
    const bar = reveal && SHD.dom.passthrough(reveal);
    if (!bar) return false;
    const callerAlive = alive;
    alive = () => callerAlive() && bar.isConnected;
    reveal.scrollIntoView?.({ block: 'center' });
    let host = r.host;
    if (!host && kind === 'comment') {
      const btn = await waitFor(() => replyControl(target), timings.composeWaitMs, alive);
      if (!alive()) return false;
      if (!btn) return false;
      btn.click();
    }
    host = host || await waitFor(() => findHost(target, kind), timings.composeWaitMs, alive);
    if (!alive()) return false;
    if (!host) return false;
    /* The same gate compose() applies, because the same closed box reaches here: a reader
       handed an unopened composer with their draft "in" it has been handed nothing. Try to
       open it the one way that works, and carry the text only into an editor they can see —
       otherwise the exit-bar sentence about clicking it once is the accurate one. */
    openComposer(host);
    await useMarkdown(host, alive);
    if (!alive()) return false;
    const editor = await waitFor(() => editorOf(host), timings.composeWaitMs, alive);
    if (!alive()) return false;
    if (!editor) return false;
    /* ALREADY THERE IS ALREADY CARRIED. compose() may have put the words into this very
       editor and then misjudged its own work — the multi-line case did exactly that, and
       this call wrote the draft a second time into a box that already held it, run
       together with no break between. Whatever insertText() concluded, the editor's
       contents must match the entire draft and survive reconciliation before the
       handoff's job is done. A substring could be buried inside accumulated old drafts. */
    if (await landed(editor, text)) return alive();
    if (!alive()) return false;
    return await insertText(editor, text, alive);
  }

  const STEP_COPY = {
    'reply-control': 'could not find Reddit\'s reply button for this comment',
    composer: 'could not get Reddit to open its reply box',
    editor: 'could not find the text field in Reddit\'s reply box',
    insert: 'could not put the text into Reddit\'s reply box',
    submit: 'could not find Reddit\'s submit button'
  };

  /**
   * WHAT TO DO ABOUT IT, for a reader now looking at Reddit's own page.
   *
   * Separate from STEP_COPY because on this side of a handoff the diagnosis is the less
   * useful half of the sentence. The reader does not need to know which selector missed;
   * they need the next action, and for the commonest failure there is a good one.
   *
   * THE SECOND ATTEMPT WORKS, and that is a measurement rather than a hope. Reddit mounts
   * its rich editor only on a real user gesture — tested from a live thread, where
   * host.click() and a full synthetic pointer sequence both produced nothing at all, and a
   * genuine click produced a working editor immediately. Our own click cannot be trusted
   * and never will be. But the reader's can: once THEY have opened the box, the composer
   * stays open, so coming back and pressing save again finds a live editor and the whole
   * chain completes. So the instruction is two clicks, not "retype it".
   */
  const HANDOFF_COPY = {
    composer: 'Reddit only opens its reply box when you click it yourself — click it once, ' +
              'then press “← back to sheddit” and save again',
    editor: 'Reddit only opens its reply box when you click it yourself — click it once, ' +
            'then press “← back to sheddit” and save again'
  };

  /**
   * Our own text surfaces. Not a Reddit contract — these are our classes, which is why
   * they are here and not in contracts.js.
   */
  const OWN_TEXT = '.shd-reply-text, #shd-root textarea, #shd-root input';

  /**
   * Keep Reddit's keyboard shortcuts out of our own text boxes.
   *
   * Reported from a signed-in session, and it did real damage: typing into the reply box
   * inserted nothing, while every keystroke reached Reddit as a HOTKEY instead. `h` hid
   * the post being replied to, and one keystroke navigated to the submit page and took
   * the draft with it. Reddit's own composer on the same page typed fine, so this is
   * ours: Reddit's handler decides whether a key came from something editable, our box
   * is not something it recognises, and it treats the key as a shortcut.
   *
   * The characters never landed because that handler calls preventDefault(), and text
   * insertion is keydown's DEFAULT ACTION. So the fix is to stop the event reaching it —
   * and emphatically NOT to preventDefault ourselves, which would suppress the very
   * typing this restores.
   *
   * ON WINDOW, IN CAPTURE, which is the only placement that works whichever way Reddit
   * listens. Capture runs outermost node first, so a window-capture listener precedes a
   * document-level listener in both phases no matter which script registered first —
   * and registration order is not ours to win, because Reddit's bundle runs long before
   * a document_idle content script. Propagation belongs to the DOM node rather than to
   * the JavaScript realm, so stopping it here stops the page's own listeners too.
   *
   * Scoped to our surfaces. Everything outside them is Reddit's business, hotkeys
   * included — a guard that swallowed keys page-wide would be a worse bug than this one.
   */
  let keysGuarded = false;
  function guardOwnKeys() {
    if (keysGuarded) return;
    keysGuarded = true;
    const stop = (e) => {
      try { if (e.target?.closest?.(OWN_TEXT)) e.stopPropagation(); }
      catch { /* a guard must never be the thing that breaks typing */ }
    };
    for (const type of ['keydown', 'keypress', 'keyup']) {
      window.addEventListener(type, stop, true);
    }
  }

  /**
   * Old reddit's reply box: a textarea, `save` and `cancel`, a status line. `target` is
   * the native element the reply belongs to (the hidden <shreddit-comment>, or the post
   * for a top-level comment). On save the text goes through compose(); on success the
   * form goes away and the pipeline renders the comment Reddit inserted, nested where
   * Reddit put it. On a miss the form stays, draft intact. Only failures before submit
   * reveal Reddit's composer so the reader can finish there.
   */
  function replyForm(m, { kind = 'comment', onClose } = {}) {
    guardOwnKeys();
    const key = draftKey(m, kind);
    const epoch = generation;
    let withdrawn = false;
    let submitted = drafts.get(key)?.submitted || false;
    const ta = h('textarea.shd-reply-text', { rows: '6', 'aria-label': kind === 'post' ? 'comment' : 'reply' });
    ta.value = drafts.get(key)?.text || '';
    const status = h('span.shd-reply-status', { role: 'status', 'aria-live': 'polite' });
    const save = h('button.shd-reply-save', { type: 'submit', text: submitted ? 'retry anyway' : 'save' });
    const cancel = h('button.shd-reply-cancel', {
      type: 'button', text: 'cancel', onclick: () => { if (!cancel.disabled) close(); }
    });
    const form = h('form.usertext.shd-reply-form', { dataset: { shdKind: kind } }, [
      h('div.usertext-edit', null, [
        ta,
        h('div.bottom-area', null, [
          status,
          h('div.usertext-buttons', null, [save, cancel])
        ])
      ])
    ]);
    const live = () => !withdrawn && epoch === generation && form.isConnected && active();
    const remember = () => {
      if (ta.value) drafts.set(key, { text: ta.value, submitted });
      else drafts.delete(key);
    };
    forms.set(form, remember);
    ta.addEventListener('input', remember);
    if (submitted) status.textContent = 'Your previous reply may already have posted; check the thread before sending it again.';
    const close = () => {
      withdrawn = true;
      drafts.delete(key);
      forms.delete(form);
      form.remove();
      if (onClose) onClose();
    };
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!live() || save.disabled) return;
      const text = ta.value.trim();
      if (!text) { status.textContent = 'nothing to save'; return; }
      save.disabled = true;
      ta.disabled = true;
      status.textContent = 'submitting…';
      form.dataset.shdState = 'submitting';
      let r;
      remember();
      try { r = await compose(m.source, text, kind, {
        alive: live,
        onSubmit: () => { submitted = true; cancel.disabled = true; remember(); }
      }); }
      catch (err) { r = { ok: false, step: 'insert', host: null, err }; }
      if (!live()) return;
      if (r.ok) { form.dataset.shdState = 'done'; close(); return; }
      save.disabled = false;
      ta.disabled = false;
      cancel.disabled = false;
      form.dataset.shdState = 'failed';
      form.dataset.shdStep = r.step;
      if (r.step === 'cancelled') {
        status.textContent = 'Reply interrupted. Your draft is still here; save again when ready.';
        return;
      }
      /* Reddit said no, in words: nothing posted, so there is nothing to check and nothing
         to hand off. Say what Reddit said and keep the draft for a deliberate retry. */
      if (r.step === 'rejected') {
        submitted = false;
        save.textContent = 'save';
        remember();
        status.textContent = `Reddit did not post this: ${r.message || 'it returned an error'}. ` +
          'Your draft is still here.';
        return;
      }
      // The submit fired. Keep the thread visible so the reader can check for the comment
      // instead of revealing a native composer that Reddit may already have closed.
      if (r.step === 'arrival') {
        form.dataset.shdCarried = 'no';
        save.textContent = 'retry anyway';
        status.textContent = 'Your comment may already have posted. Check this thread before retrying. Your draft is still here.';
        return;
      }
      status.textContent = `sheddit ${STEP_COPY[r.step] || 'could not post this'} — opening Reddit's own reply box`;
      let carried = false;
      try { carried = await handoff(m.source, kind, text, r, live); }
      catch { carried = false; }
      if (!live()) return;
      form.dataset.shdCarried = carried ? 'yes' : 'no';
      const said = carried
          ? `sheddit ${STEP_COPY[r.step] || 'could not post this'} — your text is in Reddit's reply box; press its own reply button to post it`
          : `sheddit ${STEP_COPY[r.step] || 'could not post this'} — ${
              HANDOFF_COPY[r.step] || 'your text is still here, behind “← back to sheddit”'}`;
      status.textContent = said;
      /* AND ON THE SIDE OF THE PAGE THE READER IS NOW LOOKING AT. The line above is inside
         #shd-root, which the handoff has just hidden — so on its own it is an explanation
         delivered to nobody, including the one that says "your text is still here". The
         exit bar is the only surface of ours that survives a passthrough. */
      SHD.dom.passthroughNote(said);
    });
    return form;
  }

  /**
   * The `reply` link's behaviour. Logged out (or with the layer off) it is 0.33.0's
   * handoff: passthrough to Reddit's own comment. Logged in it opens our form under the
   * comment's entry, once — a second click focuses the one that is open.
   */
  function reply(m, thing, focus = true) {
    if (!active()) {
      if (SHD.dom.passthrough(m.source)) m.source.scrollIntoView?.({ block: 'center' });
      return;
    }
    const entry = thing.querySelector(':scope > .entry') || thing;
    const open = entry.querySelector(':scope > .shd-reply-form');
    if (open) { open.querySelector('textarea')?.focus(); return; }
    const form = replyForm(m, { kind: 'comment' });
    entry.appendChild(form);
    if (focus) form.querySelector('textarea')?.focus();
  }

  function restoreReply(m, thing) {
    if (active() && drafts.has(draftKey(m, 'comment'))) reply(m, thing, false);
  }

  function ownsComment(m) {
    if (!active()) return false;
    const name = SHD.session.username();
    return !!name && name.toLowerCase() === m.author.toLowerCase();
  }

  /** The native comment behind a rendered row, found again if Reddit has replaced it. */
  function nativeComment(m) {
    if (m.source?.isConnected) return m.source;
    return [...document.querySelectorAll(C.COMMENT)]
      .find(el => el.getAttribute(C.COMMENT_ATTR.id) === m.id) || null;
  }

  function editLink(m, thing) {
    if (!ownsComment(m)) return null;
    /* The handoff this link opened (dom.passthrough's exit bar), not a busy flag. A flag
       stayed set until the pending waits timed out, so for 3-4 s after the reader pressed
       back their next click on edit did nothing at all. The bar is gone the moment they
       leave, and the attempt it belonged to stops at its next poll (editComment). */
    let open = null;
    const link = h('a.edit', { href: '#', text: 'edit' });
    return h('li', { onclick: async (e) => {
      e.preventDefault();
      if (open?.isConnected) return;
      if (!ownsComment(m)) {
        link.textContent = 'editing unavailable: not signed in as this author';
        return;
      }
      link.textContent = 'edit';
      const source = nativeComment(m);
      open = SHD.dom.passthrough(source);
      if (!open) {
        // Nothing was handed off, so there is no exit bar to say it in: the link is all
        // the reader can see.
        link.textContent = 'comment not found; reload to edit';
        return;
      }
      m.source = source;
      const bar = open;
      try {
        await editComment(m, thing, bar);
      } catch (error) {
        console.warn('[sheddit] could not open Reddit\'s comment editor', error);
        if (bar.isConnected) commentEditFallback(source, bar);
      }
    } }, link);
  }

  function commentEditFallback(source, bar) {
    SHD.dom.passthroughNote('Could not open the editor automatically.');
    const thread = source.closest(C.MAIN);
    if (!thread) return;
    bar.appendChild(h('a.shd-native-thread', {
      href: '#', text: 'open full Reddit thread',
      onclick: (e) => {
        e.preventDefault();
        if (!bar.isConnected || !thread.isConnected) return;
        if (SHD.dom.passthrough(thread)) {
          SHD.dom.passthroughNote('Use Reddit’s comment menu to edit.');
          source.scrollIntoView?.({ block: 'center' });
        }
      }
    }));
  }

  /**
   * Open Reddit's own editor on the reader's comment, inside the handoff `bar` belongs to.
   *
   * Every wait stops when that handoff closes. Not when the comment's path loses its
   * passthrough classes: a later handoff to a reply nested under this comment puts them
   * straight back, and an attempt the reader had already left then woke up and opened this
   * comment's editor beside the reply's.
   */
  async function editComment(m, thing, bar) {
    const source = m.source;
    source.scrollIntoView?.({ block: 'center' });
    SHD.dom.passthroughNote('Opening Reddit\'s editor for your comment...');
    refreshOnReturn(m, thing, bar);

    const stillHere = () => bar.isConnected && source.isConnected;
    const owned = (selector) => [...source.querySelectorAll(selector)]
      .filter(el => ownerComment(el) === source);
    const findMenuButton = () => {
      const menu = owned(C.NATIVE.commentOverflow)[0];
      return menu && SHD.dom.deepQuery(menu, C.NATIVE.commentActions);
    };
    /* The editor's text field, from whichever of this comment's edit hosts has one showing.
       Every host is asked, not the first: one Reddit left behind after a cancel or a save
       has no usable field, and taking it for THE editor skipped the menu and failed every
       later attempt on this comment until a reload. */
    const field = (open = false) => {
      const hosts = owned(C.NATIVE.commentEditHost);
      for (const host of hosts) {
        const input = SHD.dom.deepQuery(host, C.COMPOSER.editor);
        if (shown(input)) return input;
      }
      if (open) {
        // Reddit's ready slot is not projected until focus, so the closed host has no box.
        for (const host of hosts) {
          if (SHD.dom.deepQuery(host, C.COMPOSER.editor)) host.focus?.();
        }
      }
      return null;
    };
    const fallback = () => commentEditFallback(source, bar);

    if (!field()) {
      const toggle = await waitFor(findMenuButton, timings.hydrateWaitMs, stillHere);
      if (!stillHere()) return;
      if (!toggle) { fallback(); return; }
      if (toggle.getAttribute('aria-expanded') !== 'true') toggle.click();
      const edit = await waitFor(() => {
        const menu = owned(C.NATIVE.commentOverflow)[0];
        const item = menu && SHD.dom.deepQuery(menu, C.NATIVE.commentEdit);
        return item && C.NATIVE.commentEditText.test(item.textContent.trim()) ? item : null;
      }, timings.composeWaitMs, stillHere);
      if (!stillHere()) return;
      if (!edit) { fallback(); return; }
      edit.click();
    }
    const input = await waitFor(() => field(true), timings.composeWaitMs, stillHere);
    if (!stillHere()) return;
    if (!input) { fallback(); return; }
    SHD.dom.passthroughNote('Edit and save in Reddit\'s editor, then choose \u2190 back to sheddit.');
  }

  /**
   * Our row shows a CLONE of the comment's body, so an edit made in Reddit's editor does
   * not appear in it until it is copied again. Copy when the reader leaves the handoff —
   * and keep copying for editRefreshMs after: Save re-renders the body when Reddit's
   * request returns, which on a slow connection is after the reader has pressed back, and
   * a single copy at that moment kept the old text until a reload.
   */
  function refreshOnReturn(m, thing, bar) {
    const opts = { childList: true, subtree: true, characterData: true };
    let copied = null;
    let watched = null;
    let stop = 0;
    const watch = new MutationObserver(() => copy());
    const end = () => { watch.disconnect(); clearTimeout(stop); };
    const copy = () => {
      if (!thing.isConnected) return end();
      const current = nativeComment(m);
      const body = current && SHD.model.comment(current)?.bodyNode;
      const rendered = thing.querySelector(':scope > .entry > .usertext > .usertext-body');
      if (!body || !rendered) return;
      if (current !== watched) {
        // Reddit may replace the whole comment on save; its parent sees that happen.
        watched = current;
        watch.observe(current, opts);
        if (current.parentNode) watch.observe(current.parentNode, { childList: true });
      }
      if (body.innerHTML === copied) return;
      copied = body.innerHTML;
      rendered.replaceChildren(SHD.dom.adoptBody(body));
      m.source = current;
      m.bodyNode = body;
    };
    const left = new MutationObserver(() => {
      if (bar.isConnected) return;
      left.disconnect();
      copy();
      stop = setTimeout(end, timings.editRefreshMs);
    });
    left.observe(bar.parentNode, { childList: true });
  }

  /** The top-level comment box on a comments page — old reddit had one above the list. */
  /* ------------------------------------------------------------------ *
   * Delete, hide and post edit — Reddit's own menu items, clicked
   *
   * Nothing here makes a request. Each action finds the item Reddit's own overflow menu
   * offers for the row (measured signed in, 2026-11-01; see C.NATIVE) and clicks it, and a
   * delete then clicks Reddit's own confirm. A control Reddit has not rendered is a control
   * the reader is not allowed to use, so a miss is reported, never worked around.
   * ------------------------------------------------------------------ */

  const textOf = (el) => String(el?.textContent || '').replace(/\s+/g, ' ').trim();

  function ownsPost(m) {
    if (!active()) return false;
    const name = SHD.session.username();
    return !!name && !!m.author && name.toLowerCase() === m.author.toLowerCase();
  }

  /** One of a post's overflow items, waiting for the post to hydrate if it has not. */
  function postItem(m, selector, text) {
    const find = () => {
      const item = SHD.dom.deepQuery(m.source, selector);
      return item && (!text || text.test(textOf(item))) ? item : null;
    };
    const now = find();
    if (now) return Promise.resolve(now);
    return resolveLate(m.source, find, () => !!m.source?.isConnected);
  }

  /** Click Reddit's confirm button, then wait for its dialog to close: that is the answer. */
  async function confirmNative(selector) {
    const button = await waitFor(() => document.querySelector(selector), timings.composeWaitMs);
    if (!button) return false;
    button.click();
    return !!(await waitFor(() => !button.isConnected, timings.arriveWaitMs));
  }

  /**
   * Old reddit's inline confirm: `delete` becomes `are you sure? yes / no`, and nothing
   * happens until yes. `run` resolves true when the delete went through, or a sentence
   * saying why it did not.
   */
  function confirmLink(title, run) {
    const li = h('li.shd-delete');
    const status = h('span.shd-delete-status', { role: 'status' });
    const idle = () => li.replaceChildren(
      h('a.delete', { href: '#', text: 'delete', title, onclick: ask }), status);
    function ask(e) {
      e.preventDefault();
      status.textContent = '';
      li.replaceChildren(
        h('span.shd-delete-ask', { text: 'are you sure? ' }),
        h('a.yes', { href: '#', text: 'yes', onclick: yes }),
        ' / ',
        h('a.no', { href: '#', text: 'no', onclick: (ev) => { ev.preventDefault(); idle(); } }));
    }
    async function yes(e) {
      e.preventDefault();
      li.replaceChildren(h('span.shd-delete-busy', { text: 'deleting\u2026' }));
      let result;
      try { result = await run(); } catch (err) {
        console.warn('[sheddit] delete failed', err);
        result = 'delete failed';
      }
      if (result === true) { li.replaceChildren(h('span.shd-delete-done', { text: 'deleted' })); return; }
      idle();
      status.textContent = ` ${result}`;
    }
    idle();
    return li;
  }

  /** Drop buttons that can no longer do anything on a deleted row. Only this row's own
   *  button list: a comment's replies keep theirs. */
  function dropDeadButtons(thing, sel) {
    for (const ul of thing.querySelectorAll('ul.flat-list.buttons')) {
      if (ul.closest('.thing') !== thing) continue;
      for (const a of ul.querySelectorAll(sel)) a.closest('li')?.remove();
    }
  }

  /** Our row for a comment the reader just deleted, drawn the way old reddit drew one. */
  function markCommentDeleted(thing) {
    thing.classList.add('deleted');
    dropDeadButtons(thing, 'a.edit, a.reply');
    const author = thing.querySelector(':scope > .entry > .tagline > .author');
    author?.replaceWith(h('em.author', { text: '[deleted]' }));
    thing.querySelector(':scope > .entry > .usertext > .usertext-body')
      ?.replaceChildren(h('p', { text: '[deleted]' }));
  }

  async function deleteComment(source) {
    const alive = () => source.isConnected;
    const menu = () => [...source.querySelectorAll(C.NATIVE.commentOverflow)]
      .find(el => ownerComment(el) === source);
    nudge(source);
    const toggle = await waitFor(() => {
      const mm = menu();
      return mm && SHD.dom.deepQuery(mm, C.NATIVE.commentActions);
    }, timings.hydrateWaitMs, alive);
    if (!toggle) return false;
    if (toggle.getAttribute('aria-expanded') !== 'true') toggle.click();
    // The inner element, not the menuitem: a click on the <li> itself does nothing.
    const item = await waitFor(() => {
      const mm = menu();
      const it = mm && SHD.dom.deepQuery(mm, C.NATIVE.commentDelete);
      return it && C.NATIVE.commentDeleteText.test(textOf(it)) ? it : null;
    }, timings.composeWaitMs, alive);
    if (!item) return false;
    item.click();
    return confirmNative(C.NATIVE.commentDeleteConfirm);
  }

  /** `delete` on the reader's own comment. */
  function deleteLink(m, thing) {
    if (!ownsComment(m)) return null;
    return confirmLink('Delete this comment', async () => {
      if (!ownsComment(m)) return 'not signed in as this author';
      const source = nativeComment(m);
      if (!source) return 'comment not found; reload to delete';
      m.source = source;
      if (!(await deleteComment(source))) {
        return 'could not reach Reddit\'s delete; use the comment\'s own menu';
      }
      markCommentDeleted(thing);
      return true;
    });
  }

  /** `delete` on the reader's own post. */
  function postDeleteLink(m) {
    return confirmLink('Delete this post', async () => {
      if (!ownsPost(m)) return 'not signed in as this author';
      const item = await postItem(m, C.NATIVE.postDelete);
      if (!item) return 'could not reach Reddit\'s delete; use the post\'s own menu';
      item.click();
      if (!(await confirmNative(C.NATIVE.postDeleteConfirm))) {
        return 'Reddit did not confirm the delete';
      }
      for (const r of document.querySelectorAll(`#shd-root ${SHD.dom.rowSel(m.id)}`)) {
        r.classList.add('shd-deleted');
        dropDeadButtons(r, 'a.edit');
        r.querySelector('.tagline .author')?.replaceWith(h('em.author', { text: '[deleted]' }));
      }
      return true;
    });
  }

  /**
   * `edit` on the reader's own text post: Reddit's editor, in a handoff, the way a
   * comment's edit works. The comments page re-copies the post body when Reddit saves it
   * (comments.js watchPostBody), so the change shows on return.
   */
  function postEditLink(m) {
    let open = null;
    const link = h('a.edit', { href: '#', text: 'edit' });
    return h('li', { onclick: async (e) => {
      e.preventDefault();
      if (open?.isConnected) return;
      if (!ownsPost(m)) { link.textContent = 'editing unavailable: not signed in as this author'; return; }
      link.textContent = 'edit';
      const source = m.source;
      open = SHD.dom.passthrough(source);
      if (!open) { link.textContent = 'post not found; reload to edit'; return; }
      const bar = open;
      const alive = () => bar.isConnected && source.isConnected;
      const host = () => SHD.dom.deepQuery(source, C.NATIVE.postEditHost);
      const fallback = () => SHD.dom.passthroughNote(
        'Could not open the editor automatically. Use the post\'s menu > Edit post body.');
      SHD.dom.passthroughNote('Opening Reddit\'s editor for your post...');
      if (!host()) {
        const item = await waitFor(() => SHD.dom.deepQuery(source, C.NATIVE.postEdit),
          timings.hydrateWaitMs, alive);
        if (!alive()) return;
        if (!item) { fallback(); return; }
        item.click();
      }
      const ready = await waitFor(host, timings.composeWaitMs, alive);
      if (!alive()) return;
      if (!ready) { fallback(); return; }
      SHD.dom.passthroughNote('Edit and save in Reddit\'s editor, then choose \u2190 back to sheddit.');
    } }, link);
  }

  /** The post-row links only the author gets: edit (text posts) and delete. */
  function postOwnerLinks(m) {
    if (!ownsPost(m)) return [];
    return [m.isSelf ? postEditLink(m) : null, postDeleteLink(m)].filter(Boolean);
  }

  /**
   * Hide a post with Reddit's own hide, so it stays hidden everywhere. Returns false when
   * there is no session to hide it for, and the caller hides the row locally instead.
   *
   * The row is hidden at once and an undo stub takes its place; the native click follows
   * when the post's menu is reachable. If it never is, the stub says the hide was local.
   */
  function hidePost(m, rowEl) {
    if (!active() || !m.source) return false;
    const status = h('span.shd-hidden-status', { role: 'status' });
    const undo = h('a.shd-unhide', { href: '#', text: 'undo' });
    const stub = h('div.shd-hidden-stub', null, [h('span', { text: 'post hidden' }), ' \u00b7 ', undo, status]);
    rowEl.classList.add('shd-hidden');
    rowEl.after(stub);
    let hidden = postItem(m, C.NATIVE.postHide, C.NATIVE.postHideText).then((item) => {
      if (!item) {
        status.textContent = ' (on this page only: Reddit\'s hide was not available)';
        return false;
      }
      item.click();
      return true;
    });
    undo.addEventListener('click', async (e) => {
      e.preventDefault();
      if (undo.dataset.busy) return;
      undo.dataset.busy = '1';
      const wasNative = await hidden;
      if (wasNative) {
        const item = await postItem(m, C.NATIVE.postHide, C.NATIVE.postUnhideText);
        if (!item) {
          delete undo.dataset.busy;
          status.textContent = ' could not undo; use the post\'s own menu';
          return;
        }
        item.click();
      }
      hidden = Promise.resolve(false);
      stub.remove();
      rowEl.classList.remove('shd-hidden');
    });
    return true;
  }

  function unhideLink(m, onUnhidden) {
    const status = h('span.shd-hidden-status', { role: 'status' });
    const link = h('a.unhide', { href: '#', text: 'unhide', onclick: async (e) => {
      e.preventDefault();
      if (link.dataset.busy || !active()) return;
      link.dataset.busy = '1';
      status.textContent = ' unhiding…';
      const alive = () => link.isConnected && m.source?.isConnected && active();
      const item = await postItem(m, C.NATIVE.postHide, C.NATIVE.postUnhideText);
      if (item && alive()) {
        item.click();
        const unhidden = await waitFor(() => {
          const current = SHD.dom.deepQuery(m.source, C.NATIVE.postHide);
          return current && C.NATIVE.postHideText.test(textOf(current));
        }, timings.arriveWaitMs, alive);
        if (unhidden && alive()) { onUnhidden(); return; }
      }
      if (link.isConnected) status.textContent = ' could not confirm unhide; check Reddit’s post menu';
      delete link.dataset.busy;
    } });
    return h('li', null, [link, status]);
  }

  function commentBox(m) {
    if (!active()) return null;
    return h('div.shd-commentbox', null, replyForm(m, { kind: 'post' }));
  }

  /* ------------------------------------------------------------------ *
   * Post — the two doors to Reddit's composer
   * ------------------------------------------------------------------ */

  /**
   * Old reddit's sidebar buttons: "Submit a new link" / "Submit a new text post". Real
   * links onto Reddit's own composer route, which Sheddit never renders (route.js → OTHER)
   * and which therefore works exactly as Reddit built it. Posting is the one of the three
   * that is NOT delegated in place: the composer is a whole page with its own rules
   * (flair, media, crossposts, community rules), and reimplementing it is precisely the
   * work CONTRIBUTING says not to do.
   */
  function submitBox(sub) {
    if (!active()) return null;
    const base = sub ? `/r/${sub}/${C.SUBMIT.path}/` : `/${C.SUBMIT.path}/`;
    return h('div.sidebox.submit.shd-submit', null, [
      h('a.morelink.shd-submit-link', { href: `${base}?type=${C.SUBMIT.types.link}`, text: 'Submit a new link' }),
      h('a.morelink.shd-submit-text', { href: `${base}?type=${C.SUBMIT.types.text}`, text: 'Submit a new text post' })
    ]);
  }

  /* ------------------------------------------------------------------ *
   * The account corner
   * ------------------------------------------------------------------ */

  /* The one navigation this module performs, behind an indirection so the suite can watch
     it happen. jsdom implements no navigation, so a real `location.reload()` in a test is
     reported as an unimplemented feature rather than as the outcome it is — and "did the
     reader actually get logged out" is exactly the assertion worth having. Nothing in the
     extension replaces this. */
  const nav = { reload: () => location.reload() };

  /* The open menu, so a route change can close it — chrome.reset() removes the header, but
     the document-level listeners below would outlive it. */
  let openMenu = null;
  /* Raised while logOut() is pressing Reddit's own controls, so the corner does not read
     our own programmatic click as the reader clicking away from it. */
  let driving = false;

  function closeMenu() {
    if (!openMenu) return;
    const { menu, toggle, onDocClick, onKey } = openMenu;
    openMenu = null;
    menu.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
    document.removeEventListener('click', onDocClick, true);
    document.removeEventListener('keydown', onKey, true);
  }

  const item = (child) => h('li.shd-account-item', { role: 'none' }, child);
  const menuLink = (href, text, title) =>
    item(h('a', { href, text, title, role: 'menuitem' }));

  /**
   * The menu's contents, built ON OPEN rather than at render time.
   *
   * Deliberate: the reader's name may not have resolved when the header was drawn — the
   * header hydrates late, and the drawer that carries the profile link later still — and
   * the two items that need a name are worth having whenever it turns up. Everything that
   * does not need one is always here, which is what makes `log out` reachable on a session
   * whose username Sheddit never managed to read.
   *
   * The links are ordinary hrefs onto Reddit's own pages: the profile is one Sheddit
   * renders itself, the rest are routes it hands back untouched. Nothing here is delegated
   * except the last item.
   */
  function fillMenu(menu, status) {
    const name = SHD.session.username({ fresh: true });
    const kids = [];
    if (name) {
      kids.push(menuLink(`/user/${name}/`, 'my profile'));
      kids.push(menuLink(`/user/${name}/${C.ACCOUNT.savedTab}/`, 'saved'));
    } else {
      kids.push(item(h('span.shd-account-status', {
        text: 'Sheddit couldn’t read your username. Profile, saved, edit, and delete are unavailable here.'
      })));
    }
    kids.push(menuLink(C.ACCOUNT.inbox, 'messages'));
    kids.push(menuLink(C.ACCOUNT.settings, 'preferences'));
    kids.push(item(h('button.shd-account-logout', {
      type: 'button', role: 'menuitem',
      text: 'log out',
      title: 'Ends your Reddit session by pressing Reddit\'s own log-out control.',
      onclick: (e) => { e.preventDefault(); logOut(e.currentTarget, status); }
    })));
    kids.push(item(status));
    menu.replaceChildren(...kids);
  }

  /* ---------------- log out ---------------- */

  /* Where Reddit's drawer content can be: inside the header, or portaled beside it. Both
     are searched, because a panel that is a SIBLING of the header is what the upsell
     taught us to expect (C.NATIVE_UPSELL). */
  function drawerRoots() {
    const roots = [];
    const header = document.querySelector(C.HEADER);
    if (header) roots.push(header);
    document.querySelectorAll(C.USER_DRAWER.host).forEach(el => roots.push(el));
    return roots;
  }

  /**
   * Reddit's drawer PANEL — the thing that holds the log-out control — and never the
   * avatar button that opens it.
   *
   * `C.USER_DRAWER.host` leads with `[id*="user-drawer" i]`, and the toggle's own id is
   * `#expand-user-drawer-button`, which contains that string. querySelector returns the
   * first match in DOCUMENT ORDER and the button is in the header, above where the panel
   * mounts — so the "reveal Reddit's drawer" fallback was handing passthrough() the
   * BUTTON. passthrough() then walks the corridor to it and display:none's every sibling
   * on the way, which is where the panel it had just opened sits: a blanked page showing
   * one avatar button, with the log-out control hidden by our own class. The opposite of
   * what the fallback promises.
   */
  /**
   * The drawer's panel, for the reveal fallback — never the toggle, and never anything
   * INSIDE the toggle either.
   *
   * The second exclusion is the fix for a measured miss. `host` leads with a loose
   * `[id*="user-drawer"]`, which matches faceplate-partial#user-drawer-avatar-logged-in —
   * the avatar, sitting inside the toggle button and earlier in document order than the
   * panel. Revealing it corridored passthrough() down to the avatar and display:none'd
   * every sibling on the way, #user-drawer-content included: a dark page, the avatar alone
   * at top-left, and Reddit's drawer nowhere. The named panel is asked for first so the
   * loose clause only ever decides when the named one is absent.
   */
  function drawerPanel() {
    const toggle = document.querySelector(C.USER_DRAWER.toggle);
    const usable = (el) => !!el && el !== toggle &&
      !(toggle && (el.contains(toggle) || toggle.contains(el)));
    /* Two lookups, not one selector list. querySelectorAll('#named, [loose]') returns
       DOCUMENT order whatever order the clauses are written in, so a combined query would
       hand back the avatar partial first regardless — the named panel is only "first" if
       it is asked for on its own. The exclusion above is what carries the case where the
       named panel is absent altogether. */
    const named = document.querySelector(C.USER_DRAWER.content);
    if (usable(named)) return named;
    return [...document.querySelectorAll(C.USER_DRAWER.host)].find(usable) || null;
  }

  /**
   * Reddit's own log-out control, or null.
   *
   * The attribute clauses first. The text fallback then follows the AGE GATE's rule rather
   * than the reply control's: it clicks only when EXACTLY ONE control in the drawer says
   * exactly "log out". A reply button matched loosely costs a mis-click; a log-out button
   * matched loosely ends the reader's session on something that merely mentions the words,
   * and there is no undo for that short of signing back in.
   */
  function findLogoutControl() {
    for (const root of drawerRoots()) {
      const byAttr = SHD.dom.deepQuery(root, C.NATIVE.logout);
      if (byAttr) return byAttr;
    }
    const exact = [];
    const scan = (root, depth) => {
      if (!root || depth > 8 || typeof root.querySelectorAll !== 'function') return;
      for (const el of root.querySelectorAll(C.NATIVE.logoutScan)) {
        if (C.NATIVE.logoutText.test((el.textContent || '').trim())) exact.push(el);
      }
      if (root.shadowRoot) scan(root.shadowRoot, depth + 1);
      for (const el of root.querySelectorAll('*')) if (el.shadowRoot) scan(el.shadowRoot, depth + 1);
    };
    drawerRoots().forEach(r => scan(r, 0));
    // Deduplicate: an element inside a drawer that is itself inside the header is reached twice.
    const unique = [...new Set(exact)];
    return unique.length === 1 ? unique[0] : null;
  }

  function readyLogoutControl() {
    const ctl = findLogoutControl();
    if (!ctl?.isConnected || ctl.matches(':disabled, [aria-disabled="true"]')) return null;
    const host = ctl.closest(C.NATIVE.logoutHost);
    // Server-rendered markup can precede the custom element that installs the click handler.
    return host && !host.matches(':defined') ? null : ctl;
  }

  /**
   * End the session by pressing Reddit's own control — the delegation tier, applied to the
   * one action a reader most wants back (reported 2026-09-09).
   *
   * Sheddit does not build a logout request. It cannot: that is a POST carrying Reddit's
   * own CSRF token, and forging one would make this extension the sender of a request that
   * carries the reader's session — which it never is: its only requests (a video manifest, the
   * version file) go out with `credentials: 'omit'`.
   * So it does what the reader would do — open Reddit's user drawer and click the item in
   * it — and lets Reddit's code end the session.
   *
   * On success the page is RELOADED rather than re-rendered in place. Reddit usually
   * navigates itself, in which case this never runs; when it does not, every part of the
   * layer downstream (arrows, reply boxes, this corner) decided what to draw from a session
   * that no longer exists, and a reload is the one cheap way to make the whole page agree.
   * The reader has just ended their session, so a lost scroll position is the least of it.
   *
   * Every miss lands in the same place as the reply box's: reveal Reddit's own drawer in
   * place, so the control is one visible click away rather than a dead end.
   */
  async function logOut(button, status) {
    const say = (text) => { if (status) status.textContent = text; };
    if (driving) return false;
    if (button) button.disabled = true;
    say('logging out…');
    /* OUR OWN MENU MUST SURVIVE THIS, and nothing else here can keep it open. The corner
       closes on any click outside it, captured on document — and the first thing this
       function does is click Reddit's avatar button, which bubbles there and reads as
       exactly such a click. The menu was therefore hidden before the reader's press even
       returned, so `logging out…` and every miss message below were written into a hidden
       subtree: invisible, and unannounced too, because `role="status" aria-live="polite"`
       does not fire from a hidden container. "A message nobody can read is not a fallback"
       is this file's own rule, written for replies (see handoff()) and broken here.

       It also re-armed the press it was meant to guard: re-opening the corner rebuilds the
       menu with a fresh ENABLED `log out`, so a second run could start while the first was
       still waiting — clicking Reddit's toggle again and closing the very panel the first
       one was watching for. */
    driving = true;
    try {
      let ctl = findLogoutControl();
      if (!ctl) {
        const target = await waitFor(() =>
          findLogoutControl() || document.querySelector(C.USER_DRAWER.toggle), timings.drawerWaitMs);
        ctl = findLogoutControl();
        const toggle = !ctl && target;
        if (toggle && toggle.getAttribute('aria-expanded') !== 'true') {
          toggle.click();                       // Reddit opens its own drawer
        }
      }
      ctl = await waitFor(readyLogoutControl, timings.drawerWaitMs);
      if (!ctl) {
        if (button) button.disabled = false;
        say('could not find Reddit\'s log-out control — its own menu is shown instead');
        const panel = drawerPanel() || document.querySelector(C.HEADER);
        if (panel && SHD.dom.passthrough(panel)) panel.scrollIntoView?.({ block: 'center' });
        return false;
      }
      ctl.click();
      /* A header can disappear during hydration without ending the session. Require
         Reddit's affirmative logged-out UI before reloading, not a gap in logged-in UI. */
      const gone = await waitFor(() => SHD.session.signals().vetoed.length > 0,
                                 timings.logoutWaitMs);
      if (gone) { SHD.session.reset(); nav.reload(); return true; }
      if (button) button.disabled = false;
      say('Reddit did not end the session — its own menu is shown instead');
      const panel = drawerPanel() || document.querySelector(C.HEADER);
      if (panel && SHD.dom.passthrough(panel)) panel.scrollIntoView?.({ block: 'center' });
      return false;
    } catch (err) {
      if (button) button.disabled = false;
      say('log out failed');
      console.warn('[sheddit] log out failed', err);
      return false;
    } finally {
      driving = false;
    }
  }

  /* ---------------- the corner itself ---------------- */

  /**
   * Old reddit's `#header-bottom-right`, at the far right of the header, and the answer to
   * "does this thing know I am logged in?".
   *
   * SIGNED IN it is a button — the avatar and the name are the control, not decoration,
   * which is the correction reported on 2026-09-09: only `preferences` had been clickable,
   * so the part of the corner that names you did nothing. It opens a menu of Reddit's own
   * account destinations, ending in `log out`.
   *
   * SIGNED OUT it is one grey word, `logged out`, linking to Reddit's login page. That is
   * an owner decision of the same date and a reversal of the old blanket rule against
   * login affordances; the rule was written against Reddit's unremovable interstitial, and
   * a reader who keeps an account being told where the door is, once, in the corner where
   * a door has always been, is not that. It answers the same question in the negative,
   * which is the whole reason the corner exists.
   *
   * Absent entirely when the reader turns the account layer off — the one setting that
   * says "behave as though I had no account at all".
   */
  function headerAccount() {
    if (!SHD.settings?.account) return null;
    return SHD.session.loggedIn() ? signedInCorner() : signedOutCorner();
  }

  function signedOutCorner() {
    return h('span.shd-account.shd-account-signedout', null,
      h('a.shd-account-login', {
        href: C.ACCOUNT.login,
        text: 'logged out',
        title: 'Sheddit sees no Reddit session on this page. Opens Reddit\'s own login page.'
      }));
  }

  /** Reddit's unread count, or 0 when it shows no badge (which is how it says "none"). */
  function unreadCount() {
    const badge = document.querySelector(C.ACCOUNT.unreadBadge);
    const n = parseInt(badge?.getAttribute(C.ACCOUNT.unreadCountAttr) ?? '', 10);
    return Number.isFinite(n) && n > 0 ? n : 0;
  }

  /**
   * Old reddit's envelope: grey with nothing unread, orange with a count otherwise. The
   * count is Reddit's own badge, re-read on a slow tick because the badge is created and
   * removed rather than updated in place; reading an attribute costs nothing, and the tick
   * stops once the header that owns this link has been replaced.
   */
  function unreadLink() {
    const count = h('span.shd-unread-count');
    const link = h('a.shd-inbox', { href: C.ACCOUNT.notifications }, [
      h('span.shd-inbox-icon', { 'aria-hidden': 'true', text: '\u2709' }), count
    ]);
    let seen = -1;
    const sync = () => {
      const n = unreadCount();
      if (n === seen) return;
      seen = n;
      count.textContent = n ? String(n) : '';
      link.classList.toggle('shd-havemail', n > 0);
      link.title = n ? `${n} unread notification${n === 1 ? '' : 's'}` : 'No unread notifications';
    };
    sync();
    let idle = 0;
    const tick = () => setTimeout(() => {
      if (link.isConnected) { idle = 0; sync(); } else if (++idle > 3) return;
      tick();
    }, timings.unreadPollMs);
    tick();
    return link;
  }

  function signedInCorner() {
    const name = SHD.session.username();
    const avatar = SHD.session.avatar();
    const status = h('span.shd-account-status', { role: 'status', 'aria-live': 'polite' });
    const menu = h('ul.shd-account-menu', { role: 'menu', hidden: true });
    const toggle = h('button.shd-account-toggle', {
      type: 'button', 'aria-haspopup': 'true', 'aria-expanded': 'false',
      title: name ? `Signed in as u/${name} — account menu`
                  : 'Sheddit can see a Reddit session but could not read your username. ' +
                    'Voting and replying are unaffected.'
    }, [
      avatar ? h('img.shd-account-avatar', { src: avatar, alt: '', loading: 'lazy' }) : null,
      h('span.shd-account-name' + (name ? '' : '.shd-account-unnamed'),
        { text: name ? `u/${name}` : 'logged in' }),
      h('span.shd-account-caret', { 'aria-hidden': 'true', text: '\u25be' })
    ]);

    const corner = h('span.shd-account', null, [unreadLink(), toggle, menu]);

    /* ...except while logOut() is driving Reddit's own UI: the click it makes on the avatar
       button is an outside click by every test available here, and closing on it hides the
       status line the flow is still writing to. */
    const onDocClick = (e) => { if (!driving && !corner.contains(e.target)) closeMenu(); };
    const onKey = (e) => { if (e.key === 'Escape') { closeMenu(); toggle.focus(); } };

    toggle.addEventListener('click', (e) => {
      e.preventDefault();
      if (driving) return;
      if (openMenu && openMenu.menu === menu) { closeMenu(); return; }
      closeMenu();
      status.textContent = '';
      fillMenu(menu, status);
      menu.hidden = false;
      toggle.setAttribute('aria-expanded', 'true');
      openMenu = { menu, toggle, onDocClick, onKey };
      // Capture phase, so a click Reddit's own page handles still closes our menu first.
      document.addEventListener('click', onDocClick, true);
      document.addEventListener('keydown', onKey, true);
    });

    return corner;
  }

  function reset() {
    for (const [form, remember] of forms) if (form.isConnected) remember();
    forms.clear();
    generation++;
    missWarned = false;
    voteSync?.io.disconnect();
    voteSync = null;
    closeMenu();
  }

  return { midcol, vote, reply, restoreReply, editLink, deleteLink, ownsPost, postOwnerLinks, hidePost, unhideLink,
           replyForm, commentBox, compose, submitBox, headerAccount,
           logOut, findLogoutControl, nav, reset, timings };
})();

/**
 * contracts.js — THE SINGLE POINT OF BREAKAGE.
 *
 * Every selector, tag name and attribute name Reddit owns lives here and nowhere else.
 * When Reddit ships a redesign, this is the only file that should need editing.
 *
 * Verified live against reddit.com on 2026-08-12.
 */
globalThis.SHD = globalThis.SHD || {};

SHD.C = {
  /* ---------- page skeleton ---------- */
  APP: 'shreddit-app',
  MAIN: '#main-content',
  RIGHT_SIDEBAR: '#right-sidebar-container',
  SUBGRID: '#subgrid-container',
  HEADER: 'reddit-header-large',
  LEFT_NAV: 'reddit-sidebar-nav, #left-sidebar-container, nav#left-sidebar',

  /* ---------- listings ---------- */
  FEED: 'shreddit-feed',
  POST: 'shreddit-post',
  POST_WRAPPER: 'article',          // shreddit-feed > article > shreddit-post
  /* Ads are <shreddit-ad-post> and do NOT contain a <shreddit-post>, so querying
     POST excludes them for free. Verified: 28 posts scraped, 0 ads captured. */
  AD_POST: 'shreddit-ad-post',
  FEED_SEPARATOR: 'shreddit-feed > hr',
  /* Reddit's own "there is nothing here" panel, which it renders INSIDE the feed in
     place of posts. Captured live 2026-08-20 (r/911truth, logged out): one wrapper div
     whose children are an `<h1 data-testid="no-content">`, a paragraph and a link.

     It is the only affirmative "the feed has loaded and the answer is zero" signal
     Reddit gives us, and that distinction is the whole reason it is a contract rather
     than a heuristic: a feed with no posts in it is either an answer or a page that has
     not arrived yet, and counting posts cannot tell those apart — it just keeps waiting
     (bug 94). The testid is what is matched, not the copy: the wording is Reddit's and
     has already been observed to be wrong for the case it is shown in (it claims the
     community has never had a post while describing a time-filtered range with none),
     so the copy is exactly the thing we replace. */
  /* A signed-in reader's empty saved/upvoted/hidden tab (measured 2026-11-01) shows
     `div#empty-feed-content` instead. */
  FEED_EMPTY: '[data-testid="no-content"], #empty-feed-content',

  /* A profile Reddit is GATING, as opposed to one that simply has nothing on the tab.
     Reported from a live session on two accounts: Reddit serves zero post elements and
     renders its own line saying the account keeps its posts hidden. We drew the ordinary
     empty notice over that — "there doesn't seem to be anything here / u/X has nothing on
     this tab" — which describes an account that has never posted and reads, to anyone who
     knows the account HAS posted, as Sheddit failing to load them.

     A TEXT test, and an UNVERIFIED one. Nobody has captured the markup around that line,
     so there is no element or testid to key on and this reads Reddit's own words; if a
     capture ever turns up a stable attribute, that is strictly better and should replace
     this. English-only, like MORE_REPLIES_TEXT and the age gate, and documented as such
     rather than pretended otherwise — a reader on another locale gets the generic notice,
     which is the same thing they get today.

     SCOPED BY THE CALLER to the empty case on a profile route, which is what keeps the
     blast radius small: the only way to be wrong is to give a "hidden" explanation instead
     of a "nothing here" one on a page that has no posts either way. Matching loosely
     around `hidden` rather than pinning Reddit's exact sentence, because the sentence is
     theirs to change and the failure mode of a near-miss is the old copy. */
  PROFILE_HIDDEN: /\blikes to keep\b[\s\S]{0,40}?\bhidden\b/i,

  /* Pagination. The trailing partial carries loading="programmatic" — it does NOT
     self-trigger on scroll; Reddit's feed JS calls it. We call it ourselves via its
     public loadContent(). Verified live: 3 posts -> 28 posts in one call. */
  LAZY_LOADER: 'faceplate-partial',
  /* A partial that is NOT a pagination handle, by what it fetches.
     MEASURED LIVE 2026-09-21, signed in, front page: Reddit serves community hovercards as
     `faceplate-partial[loading="programmatic"]` with
     src="/svc/shreddit/community-hover-card/<sub>" — the same element and the same loading
     mode as the feed's own continuation, sitting in the feed and in no post, so neither the
     selector nor paginator.js's `!closest(ITEM)` ownership rule could tell them apart. The
     paginator drove one instead of `/svc/shreddit/feeds/home-feed`: 27 rows in, 27 out,
     repeatedly, then "no more pages". Measured again 2026-09-25, logged out, a
     /r/programming slice: 28 of its 29 partials were `/svc/shreddit/user-hover-card/<name>`,
     one per post author inside the post and one per advertiser inside the ad — which is
     where the ones outside every post were — and the 29th was the continuation.
     A NEGATIVE test, not a positive one. Requiring the src to look like a feed endpoint
     would break silently the day Reddit renames it; naming the thing we measured and have
     proof is not a handle costs a page only if Reddit reuses that path for pagination,
     which is the safer direction to be wrong in. Paired with structural rules in
     paginator.js (nothing inside a post or an ad continues a feed; a continuation follows
     the content it continues) that do not depend on knowing any src at all — see partial(). */
  PARTIAL_NOT_SRC: '[src*="hover-card" i]',
  /* THE FEED'S CONTINUATION, and it carries PARTIAL_NOT_SRC itself (run.js asserts the two
     agree). paginator.js adds the exclusion to every clause anyway; gate.js ("posts are still
     on their way") reads this selector BARE, and verify:live used to — and bare, its first
     match on the 2026-09-25 /r/programming slice was the first post's author hovercard, so
     "the programmatic pagination partial is present" could not fail while any post had an
     author, and the thin-feed drive fetched a hovercard. Even with the exclusion a bare read
     is only a first guess: on /r/aww the first match is a media-overlay partial inside the
     first post, on /popular a free `devvit-privacy-modal` partial ahead of the posts. Which
     partial is the handle is paginator.js partial()'s question — ownership, position, the
     last — and verify:live asks it the same way. */
  FEED_PARTIAL: 'shreddit-feed faceplate-partial[loading="programmatic"]:not([src*="hover-card" i])',
  /* Comment threads lazy-load the same way. ARCHITECTURE §1.5 recorded 29 pending
     partials on a real thread; we only ever drove the feed's, so anything past the
     first delivered slice of a thread was unreachable. Scoped to the comment tree so a
     stray partial elsewhere on the page cannot be mistaken for more comments.

     IT SELECTS NOTHING THE FALLBACK DOES NOT — and what it matches has moved twice.
     verify:live 2026-08-14 found ZERO in-tree partials with loading="programmatic";
     2026-08-24 found TWO (beside ~19 per-branch loading="action" expanders), so the
     selector matches real elements again. Either way it cannot do more than the broader
     `COMMENT_TREE LAZY_LOADER` clause: it is a strict SUBSET of it, and
     `querySelector('a, b')` returns the first match in DOCUMENT order, not the first
     clause with a match — so listing it first buys no preference. FEED_PARTIAL above
     sits in the same relationship to its own fallback.

     A THIRD observation, 2026-09-05 on a logged-in 2370-comment thread: 88 in-tree
     partials, ZERO programmatic. verify:live reports the count as a note now rather than
     failing the run over a fact that flips with the session.

     Both are kept anyway, deliberately, for one reason: verify:live reports on them, and
     "the feed's partial is programmatic" is the fact that explains why pagination does not
     self-trigger at all. Comment continuation itself IS settled now — the WHAT DRIVES A
     COMMENT TREE section measured it live 2026-08-24: subthread expansion, with every
     driven partial removing itself (5/5) and repeated drives making progress. */
  COMMENT_PARTIAL: 'shreddit-comment-tree faceplate-partial[loading="programmatic"]',
  /* The label on Reddit's per-branch reply expander, for the delegated control in
     comments.js. A TEXT test, exceptionally: the control is a plain button/anchor with no
     distinguishing attribute captured. Live copy observed 2026-08-20: "65 more replies",
     "70 more replies", "28 more replies" — counts vary, the phrase does not. English-only,
     like the age-gate matcher; a miss fails safe (no extra control is rendered). */
  MORE_REPLIES_TEXT: /more repl/i,
  /* The comment-sort values Reddit's page accepts in `?sort=`, with old reddit's labels
     for them. Requested twice from live use ("no comment-sort dropdown").

     VERIFIED LIVE 2026-08-24: the classic API's names are accepted. The check is
     verify:live's COMMENT SORT VALUES section — comment ids are base36-sequential over
     time, and ?sort=new delivered a strictly newer median id than ?sort=old on a
     454-comment thread, which an ignored parameter cannot produce (both loads would be
     the identical default slice). The failure stays soft by construction: a value Reddit
     stops recognising falls back to the default order — a link that mis-sorts, never a
     link that breaks — and a future break shows up in that same section as tied medians. */
  COMMENT_SORTS: [
    { id: 'confidence', label: 'best' },
    { id: 'top', label: 'top' },
    { id: 'new', label: 'new' },
    { id: 'controversial', label: 'controversial' },
    { id: 'old', label: 'old' },
    { id: 'qa', label: 'q&a' }
  ],
  /* Video posts. A bare v.redd.it link 302s a LOGGED-OUT session straight back to the
     post's comments page (measured live) — with our layout on, a closed loop: we
     render the destination, whose title links back to v.redd.it.

     CAPTURED LIVE 2026-08-20, and it corrected three guesses at once:
       - the attribute is NOT on <shreddit-post>. It sits on a nested <shreddit-player>,
         so it must be QUERIED for in the post's subtree, never read off the post.
       - it is LAZY: 1 of 4 video posts carried it at first paint, the other three had a
         player with no such attribute yet. So render-time resolution alone cannot work —
         listing.js re-resolves at CLICK time, the same lesson as the vote controls.
       - the mp4 filenames are `m2-res_<height>p.mp4`, not the `DASH_<n>` this was first
         written for. Ranking on DASH_ scored every live URL zero and would have picked
         the FIRST one, which is the LOWEST quality. model.js ranks on the largest number
         in the filename, which covers both spellings.
     The URLs carry a signature and an `e` expiry. It was recorded here as ~12h; MEASURED
     2026-09-01 on a reported post it was about FOUR hours, which is short enough to run out
     inside a long session and far short enough to be dead on any page rendered from
     yesterday's capture. An expired URL is not refused politely — the CDN answers 403 and
     the <video> reports `error.code 4` (SRC_NOT_SUPPORTED) with nothing buffered, which
     looks exactly like a codec fault. So model.mp4Of reads the deadline and drops a
     rendition that has passed it (model.expired), and the manifest below — whose CMAF files
     carry no signature at all — is what plays instead. Never cache one either way. */
  POST_VIDEO_JSON: 'packaged-media-json',
  /* A GIF in a comment or selftext body, as Reddit ships it: a <shreddit-player gif>
     whose only light-DOM <source> is the raw .gif on preview.redd.it — no `type`, no
     `poster` — wrapped in an anchor to the /media viewer. Captured live 2026-08-27
     (bug 88): 8 of 11 players on one thread, every one readyState 0, because a <video>
     cannot decode GIF; with no poster the element paints a solid black box. Our clone
     paints the same box — custom-element upgrade is document-global, so the copy in
     #shd-root comes alive as the same broken player. dom.inlineGifs swaps the clone for
     the element that can actually show what the player was starving: an <img> for a real
     GIF, which is exactly how the comment GIFs that already worked on the same page were
     delivered, and a silent looping <video> for the mp4 delivery below. */
  GIF_PLAYER: 'shreddit-player[gif]',
  /* Which of the two ways Reddit delivers that GIF this one is. Reported live 2026-08-30
     (bug 93), with the audit attached: the player's source was `<name>.gif?width=370&
     format=mp4`, and the file behind it answers 200 with `content-type: video/mp4` — an
     mp4 wearing a `.gif` filename. The extension of the URL says GIF, the QUERY says what
     is actually served, and nothing else can: reading the response header means fetching
     the file first, which this extension does not do (media.js holds its one request, and
     that one is a manifest, not a guess). So the query is the discriminator — `format=mp4`
     goes in a <video>, anything else in an <img>, and a path that already ends `.mp4` is
     covered because the one URL shape that states its format outright should not be the
     one we miss. `format=gif` — bug 88's capture, still live on the same pages — falls
     through to the <img> path unchanged. */
  GIF_MP4_SRC: /[?&]format=mp4(?:&|$)|\.mp4(?:$|[?#])/i,
  /* The asset id inside a video post's `content-href`, and the manifest that lists what
     Reddit will actually serve for it. Added 0.16.0, when the packaged renditions above
     stopped being enough: on a repackaged asset every `DASH_*`/`m2-res_*` file 403s and
     only `CMAF_<n>.mp4` serves, so the attribute above resolves nothing and there is no
     rendition to link to. The manifest names every rendition WITH its width and height,
     which is the one thing that cannot be inferred — the rungs are Reddit's encoding
     choices, not the source's size (one measured asset has 96/220/270/360/480 and no 720
     or 1080), so a constructed name repeats the `DASH_720.mp4` mistake. See media.js. */
  VIDEO_ASSET: /^https?:\/\/v\.redd\.it\/([A-Za-z0-9_-]+)/,
  VIDEO_MANIFEST: 'DASHPlaylist.mpd',
  PARTIAL_LOAD_METHOD: 'loadContent',

  /* Calling loadContent() needs src/core/bridge.js, which runs in the PAGE's main world.
     A content script cannot call it directly — see the header of bridge.js. These are our
     own names, not Reddit's; bridge.js repeats the literals because it has no access to
     this file, and test/run.js asserts the two agree. */
  BRIDGE: {
    request: 'shd:load-more',       // window event, isolated world -> main world
    selKey: 'shdPartialSel',        // <html data-shd-partial-sel>   which element to call
    methodKey: 'shdPartialMethod',  // <html data-shd-partial-method> which method to call
    resultKey: 'shdLoadMore',       // <html data-shd-load-more>      ok | no-partial | ...
    navigated: 'shd:navigated'      // window event, main world -> isolated: a page-realm
                                    // pushState/replaceState just committed — re-read location
  },

  /* Thumbnail resolution. Host allowlist + ancestor exclusion; see model.thumbnailFor.
     The allowlist exists because a loose match made every text post show a subreddit icon
     or a flair emoji (bug 1). Keep it an allowlist — never relax to *.redditmedia.com,
     which is exactly what went wrong: `styles.` is community icons and `emoji.` is flair.
     `<letter>.thumbs.redditmedia.com` IS the post-thumbnail CDN and was being rejected
     along with them; added 2026-08-14 after verify:live observed it live. */
  THUMB_HOSTS: /^((preview|i|external-preview)\.redd\.it|[a-z]\.thumbs\.redditmedia\.com)$/,
  THUMB_EXCLUDE: 'shreddit-post-flair, faceplate-hovercard, shreddit-join-button, a[href^="/user/"]',

  /* Where a gallery keeps the frames it has not shown yet.
   *
   * MEASURED LIVE on a six-frame gallery: frame 1 carries a real `src`; frames 2..N are
   * `loading="lazy"` with an EMPTY `src` and their URL parked in `data-lazy-src`. Reddit
   * fills the real `src` in when its <gallery-carousel> ADVANCES — and under this layout
   * the carousel never advances, because it is a 0x0 inert host whose own utility classes
   * match no loaded stylesheet and whose Prev/Next buttons are `visibility: hidden`.
   *
   * So this is the same shape as the feed's programmatic partial and the comment action
   * row: Reddit's lazy machinery is driven by interaction with a native tree we hide, so
   * waiting for it to deliver is waiting for something that cannot happen. The frames are
   * NOT missing, and never were — every URL is in the DOM at first paint, one attribute
   * away from the one being read. Reading it is the whole fix; nothing has to be driven,
   * clicked or waited for.
   *
   * A candidate from here scores no width (the attribute states a URL, not a size), so it
   * can never outrank a real srcset entry — it only fills a slot that would otherwise be
   * empty. That is the direction that matters: a wrong guess here costs nothing, and the
   * absence of it costs every frame after the first. */
  GALLERY_LAZY_SRC: 'data-lazy-src',

  /* The host that serves the file as UPLOADED, against the one that serves resizes of it.
   *
   * `i.redd.it/<id>.jpg` is the original; `preview.redd.it` serves generated variants of
   * the same picture at stated widths. Reported from live use: a post rendered at 640px
   * when a full-size copy was sitting in the same element. The cause is a ranking rule
   * that is right for its own question and blind to this one — the widest `w` descriptor
   * wins, and the original carries NO descriptor at all, because there is nothing for
   * Reddit to state a width against. So it scores zero and every resize outbids it.
   *
   * An original cannot be smaller than a resize of itself, which is what makes this a
   * rank and not a guess: preferring it needs no measurement, and there is no case where
   * a 640px variant is the better picture. It is used only where the FULL-SIZE picture is
   * wanted — the comments page and the listing expando. Thumbnails resolve separately and
   * are untouched, or every 70px tile in a feed would download a full upload. */
  ORIGINAL_HOST: /^i\.redd\.it$/,

  /* Observed post-type values: text, link, image, gallery, video, multi_media, crosspost
     (crosspost added 2026-08-14 by npm run verify:live; falls through the same non-text
     path as link/image/etc. in model.js. The fallback is covered rather than accidental:
     t3_crosspost1 in test/fixtures.js carries the live shape, and run.js asserts the row
     renders with the right thumbnail host). */
  /* NOT USED BY ANYTHING. model.js decides self-vs-link inline with
     `/^self\./.test(domain) || type === 'text'`, so editing this list changes no behaviour
     — a trap for whoever assumes otherwise. Left in place rather than deleted because it
     documents the intent; wire it into model.js or drop it, but do not trust it as live. */
  SELF_TYPES: ['text'],

  /* Attributes carried by <shreddit-post>. Confirmed present on both text and link posts.
     award-icon-url and is-link-post were dropped 2026-08-14: verify:live found neither
     present on every post any more, and neither was read anywhere downstream (isLink was
     never even copied into the model; awardIcon was copied but never rendered). A mapping
     to an attribute nothing consumes is not a contract, it is a false alarm waiting to
     happen — removed rather than chased. */
  POST_ATTR: {
    id: 'id',                              // t3_xxxxx
    title: 'post-title',
    permalink: 'permalink',                // /r/sub/comments/id/slug/
    contentHref: 'content-href',           // outbound URL for link posts
    type: 'post-type',                     // text | link | image | gallery | video | crosspost
    score: 'score',
    upvoteRatio: 'upvote-ratio',
    comments: 'comment-count',
    created: 'created-timestamp',          // ISO 8601
    domain: 'domain',                      // "self.Layoffs" or "theregister.com"
    author: 'author',
    subreddit: 'subreddit-name',
    subredditPrefixed: 'subreddit-prefixed-name',
    icon: 'icon',                          // optional live: 27/28 carried it, 2026-08-24
    /* `award-count` was here until 2026-08-24, kept as "still present live, a usable
       hook". A live listing then carried it on 0/28 posts — while comments still carry
       it — so the post mapping failed bug 24's own test twice over: unconsumed AND
       absent. Removed from POST_ATTR and the post model; COMMENT_ATTR keeps its copy,
       which the same day's thread run measured present 25/25. */
    index: 'feedindex'
  },

  /**
   * How a post says it is adult content.
   *
   * WHY IT MATTERS: modern Reddit blurs NSFW thumbnails in the feed for logged-out readers.
   * We do not restyle Reddit's DOM — we lift the image URL out of the post and render it
   * ourselves — so that blur is bypassed and the image lands full-size in our list. Found on
   * a graphic war-footage subreddit, logged out, which is the case where getting this wrong
   * actually costs someone something.
   *
   * VERIFIED LIVE 2026-08-18 on /r/CombatFootage/, logged out, 28 posts, 1 flagged:
   *
   *     adult post   nsfw=""      (attribute present, EMPTY string)
   *     safe post    (absent)     getAttribute -> null
   *
   * `is-nsfw`, `over-18` and `over18` were guesses and appear nowhere; the list is collapsed
   * to the one real name, because a list of guesses is not a contract. It stays an array so
   * a rename is a one-word edit, and `verify:live` now fails on any adult-looking attribute
   * it does not recognise — which is what actually protects against a rename. Carrying three
   * more unobserved spellings never did: it only helps if Reddit renames to one of exactly
   * those three, and it silently widens what counts as adult in the meantime.
   *
   * THE EMPTY STRING IS THE WHOLE POINT. `""` is falsy, so the obvious implementation —
   * `if (el.getAttribute('nsfw'))` — reads every adult post as safe and renders every
   * graphic thumbnail full-size. See nsfwOf() in model.js, which tests for ABSENCE and for
   * the literal "false"/"0" instead, so it survives both spellings a custom element can use
   * for a boolean.
   */
  NSFW_ATTRS: ['nsfw'],

  /**
   * The post's own rendered text, for the comments page.
   *
   * Post content is NOT an attribute — confirmed live 2026-08-20 (Superstonk report, and
   * consistent with every capture since): shreddit-post carries title/score/author/etc as
   * attributes, but the selftext arrives as slotted light DOM, `div[slot="text-body"]`
   * holding Reddit's rendered `.md` markup. Same deal as COMMENT_BODY, so it gets the same
   * treatment: clone the rendered node, never re-parse markdown, and scope the lookup to
   * the post that owns it.
   */
  POST_BODY: 'div[slot="text-body"]',

  /* Reddit's "Read more" truncation of a long POST_BODY — presentation state, not content.
     Measured live 2026-10-25 (r/bald q0577m, served collapsed on a revisit): the host
     `shreddit-post-text-body` lists the clamp classes in `text-body-height-class`, the same
     tokens sit on the body's `.md`, and an `#<id>-overflow-cover` gradient plus an
     `#<id>-read-more-button` follow it. The full text is already in the DOM. The button's
     click listener is bound to the native element itself (CDP getEventListeners) and fires
     `read-more-click` on the host, which strips the classes from the NATIVE `.md` only — so
     a cloned button is dead. The clone is pre-expanded instead; see watchPostBody(). */
  POST_BODY_CLAMP: {
    classAttr: 'text-body-height-class',
    chrome: '[id$="-overflow-cover"], [id$="-read-more-button"]'
  },

  /* A post Reddit has taken down, which we rendered as an ordinary one.
   *
   * Reported from live use: a deleted thread came out with a `[deleted]` author and a
   * self-post body and nothing else — no way to tell a dead thread from a live one, while
   * modern Reddit says so plainly. The cause is the one idea's third consequence (log 49
   * was selftext, 79 was images): removal is NOT AN ATTRIBUTE. Nothing on shreddit-post
   * flags it; Reddit states it in rendered copy, so the copy is the contract.
   *
   * A TEXT test, like MORE_REPLIES_TEXT and the age gate's buttons, and for the same
   * reason — no stable attribute has been captured. English-only, like both of those.
   * The phrase is the reported one verbatim ("Sorry, this post was deleted by the person
   * who originally posted it"), widened only to its known sibling: Reddit uses the same
   * sentence shape for a moderator or filter removal ("...was removed by..."). Anchored on
   * the middle of the sentence so the leading "Sorry," and whatever follows "by" are both
   * free to change.
   *
   * NOT YET SETTLED FROM A CAPTURE, and the design assumes it will be wrong before it is
   * right. What is verified is the SENTENCE, from a reader who read it on the page; what is
   * NOT is the element that carries it, so this is matched by walking text rather than by a
   * selector, and a miss costs the notice and nothing else — the post renders exactly as it
   * does today. verify:live's REMOVED POSTS section is what settles it.
   *
   * The author fallback is deliberately NOT used as the signal, though it looks like one:
   * a post whose AUTHOR deleted their account also reads `[deleted]` while the post itself
   * is perfectly readable. Treating those as removed would put a tombstone over live
   * content, which is the worse error of the two. */
  POST_REMOVED_TEXT: /th(?:is|e) (?:post|submission|comment) was (?:deleted|removed)/i,

  /* The element Reddit hydrates a post's action bar into — the place the vote buttons
     appear, late (ARCHITECTURE §1.3), and the one named in the miss report so a reader
     can say whether the bar was there at all when a delegated click found nothing. */
  ASYNC_LOADER: 'shreddit-async-loader',
  /* Native controls we delegate clicks to. Resolved AT CLICK TIME — the action bar
     lives inside a shreddit-async-loader and is not present at first paint. */
  NATIVE: {
    /* VERIFIED LIVE 2026-09-05, signed in: both buttons sit in the POST'S OWN open shadow
       root (not a descendant's — which is why every earlier probe, searching only the
       descendants' roots, reported them unreachable), as
         <button rpl aria-pressed class data-action-bar-action style upvote>   "Upvote"
         <button rpl aria-pressed class data-action-bar-action style downvote> "Downvote"
       The bare `upvote` / `downvote` attribute is the first clause and matched; the
       aria-label clause is the fallback for the day it is renamed. A COMMENT'S buttons
       (verified the same day, once its action row had hydrated on scroll) are the same
       shape one level down: <button rpl aria-pressed class style upvote> inside the open
       shadow root of its light-DOM <shreddit-comment-action-row>. Whether the same buttons
       exist on a logged-out page is now an open question again — the "not reachable"
       findings were measured through the own-root hole — and does not matter to a
       logged-out reader either way: Reddit's own click handler decides what a click does. */
    upvote: 'button[upvote], button[aria-label*="upvote" i]',
    downvote: 'button[downvote], button[aria-label*="downvote" i]',
    /* The attribute Reddit's vote buttons carry to say which way the reader has voted —
       `aria-pressed` on both arrows. VERIFIED LIVE 2026-09-05, signed in: present on both
       buttons (`false` / `false` on an unvoted post). The `"true"` side is inferred from
       the toggle-button convention — no voted post was on the probed page — and is read
       for MIRRORING only, never for deciding whether to vote: a button that lacks it
       leaves our arrows on their own local toggle. */
    voteState: 'aria-pressed',
    /**
     * Reddit's own LOG OUT item, inside the user drawer. CANDIDATES.
     *
     * `logoutText` is the fallback, and it is deliberately ANCHORED (`^log out$`) where
     * MORE_REPLIES_TEXT is not: the reply expander's label carries a count and can only be
     * matched loosely, while a loose logout match would end the reader's session on a
     * control that merely mentions the word — a "log out of all devices" row in settings,
     * a post titled "how to log out". Ending a session by accident is not a layout bug you
     * shrug at, so this one matcher is strict, scoped to the drawer, and account.js clicks
     * nothing when more than the exact phrase matches.
     */
    /* MEASURED LIVE 2026-09-17, signed in. Reddit's log-out item is none of the three
       shapes below it — it is
         user-drawer-logout > faceplate-tracker[noun=logout] > ul > li#logout-list-item
           > div[tabindex=0]  "Log Out"
       a <div> with no href, no role and no testid, and the click handler is on the CUSTOM
       ELEMENT itself (connectedCallback adds a click listener that ends the session), so a
       click anywhere inside it bubbles up and works. Nothing else is needed: no form, no
       token. Both the element and the list item are named so the attribute pass finds it
       without ever reaching the text scan; the older clauses stay as fallbacks for the
       shapes that were guessed at before anyone had looked. The item does not exist until
       the drawer has been opened — #user-drawer-content ships holding one
       faceplate-partial and fills ~1.6s after the avatar is clicked — which account.js's
       toggle-then-wait already covers; the wait was searching for the wrong thing. */
    logout: 'user-drawer-logout, #logout-list-item, ' +
            'a[href*="/logout" i], button[data-testid*="logout" i], [role="menuitem"][href*="logout" i]',
    logoutHost: 'user-drawer-logout',
    logoutText: /^log\s*out$/i,
    /* What the text fallback is allowed to consider. `[tabindex]` is there because the live
       control is a focusable <div> — without it the div carrying exactly "Log Out" was
       never looked at, and the fallback that exists for a renamed control could not see
       the one control on the page. */
    logoutScan: 'a, button, [role="menuitem"], [tabindex]',
    /* The per-comment "Reply" control, for opening Reddit's own composer on a logged-in
       session (account.js). CANDIDATE still: the 2026-09-05 signed-in probe read the
       first comment before its action row had hydrated — the only buttons under it were
       "N more replies" and a "Loading" placeholder — so NOT FOUND there says nothing yet;
       the probe now scrolls the comment into view and waits for the row. The row itself
       is a light-DOM <shreddit-comment-action-row> (28 on a live profile) with an open
       shadow root, so this is resolved with deepQuery like the vote buttons are; the
       aria-label clause is the fallback for an attribute rename, and a miss is fail-safe
       — the reply hands off to the native comment via passthrough, exactly as every
       version before 0.34.0 did.

       THE ROW DOES NOT HYDRATE ON ITS OWN WHILE OUR LAYOUT IS UP, and an early version of
       this note said resolving at click time is enough "because the reader has necessarily
       scrolled it into view". They have not: the reader scrolls OUR rows, never Reddit's,
       and Reddit builds this row off the native tree's viewport position. Reported from a
       signed-in session and reproduced with `data-shd-step=reply-control`: the control is
       simply never built.

       Resolving at click time is still right — it is just not sufficient by itself. A
       second version of this note said the row therefore could not be had without
       revealing the page, which was also wrong: suppress.css was collapsing the native
       tree to a clipped 1x1 box, and that was a side effect of hiding it rather than a
       requirement (log 107). The tree keeps its dimensions now, so account.js scrolls the
       native comment inside that box and waits for the row — for this control and for the
       vote buttons beside it, which are the same row and the same problem. handoff() stays
       as the floor beneath that, and reveals the page only when the wait has failed. */
    reply: 'button[data-post-click-location="comment-reply"], ' +
           'shreddit-comment-action-row button[aria-label*="reply" i], ' +
           'button[name="reply"], button[aria-label*="reply" i]',
    /* FOUND LIVE 2026-09-05, signed in, once the action row had hydrated: the reply
       control is a LIGHT-DOM button in the comment carrying NOTHING that names it —
         <button rpl class style> "Reply"
       — so every attribute clause above misses it, and its text is the only handle. A TEXT
       test, exactly as MORE_REPLIES_TEXT is and for the same reason; English-only, like
       that one and the age gate; anchored (^…$) so "15 more replies" and "Reply" cannot be
       confused; scoped by account.js to buttons the comment OWNS (closest(COMMENT) ===
       target), because a comment's subtree holds its descendants' reply buttons too. The
       attribute clauses stay first for the day Reddit names the control. */
    replyText: /^reply$/i,
    // Measured signed in, 2026-09-25: comment editing lives in the overflow's open root.
    // verify:live re-reads all five (EDITING YOUR OWN COMMENT): the menu signed in, the
    // edit item on a thread carrying one of the reader's own comments.
    commentOverflow: 'shreddit-overflow-menu[comment-id]',
    commentActions: 'button[aria-label="Open user actions"]',
    commentEdit: '[role="menuitem"]:has([icon-name="edit"]) [tabindex="0"]',
    commentEditText: /^edit comment$/i,
    commentEditHost: 'comment-composer-host[edit-mode]',
    /* Measured signed in, 2026-11-01. The own-comment menu (same open root as edit) has
       `li.delete-comment-menu-button[role=menuitem]` > div[tabindex=-1] "Delete comment".
       A click on the LI does nothing; the inner div opens Reddit's confirm, which is a
       light-DOM `div#comment-deletion-dialog` directly under shreddit-app, with
       `button#deleteBtn` "Delete" and `button#backBtn` "Cancel". It works with the native
       tree suppressed, so no passthrough is needed. */
    commentDelete: 'li.delete-comment-menu-button > [tabindex]',
    commentDeleteText: /^delete comment$/i,
    commentDeleteConfirm: '#comment-deletion-dialog #deleteBtn',
    /* A post's overflow items, measured signed in 2026-11-01. They are pre-rendered in
       shreddit-post-overflow-menu's open root (inside the post's async loader) with stable
       ids, and a click on the item's [role=menuitem] acts WITHOUT opening the menu:
         hide   -> graphql UpdatePostHideState {hideState: HIDDEN}; text becomes
                   "Remove from hidden", and the same item then unhides (hideState NONE).
         edit   -> (own self post) mounts `edit-post-form` with Reddit's composer inside
                   shreddit-post-text-body.
         delete -> (own post) opens `div#post-deletion-confirmation-modal` under
                   shreddit-app; its `button#deleteBtn` "Yes, Delete" sends DeletePost. */
    postHide: '#post-overflow-hide [role="menuitem"]',
    postHideText: /^hide$/i,
    postUnhideText: /^remove from hidden$/i,
    postEdit: '#post-overflow-edit [role="menuitem"]',
    postEditHost: 'edit-post-form',
    postDelete: '#post-overflow-delete [role="menuitem"]',
    postDeleteConfirm: '#post-deletion-confirmation-modal #deleteBtn',
    /* The hydrated comment action row carries the reader's standing vote as
       vote-state="UP|NONE|DOWN" (measured 2026-11-01). The server markup does not. */
    commentRow: 'shreddit-comment-action-row',
    overflow: 'shreddit-post-overflow-menu',
    textBody: 'shreddit-post-text-body',
    titleLink: 'a[slot="title"]',
    fullPostLink: 'a[slot="full-post-link"]'
  },

  /* ---------- comments ---------- */
  COMMENT_TREE: 'shreddit-comment-tree',
  COMMENT: 'shreddit-comment',
  COMMENT_ATTR: {
    id: 'thingid',                   // t1_xxxxx
    postId: 'postid',
    author: 'author',
    score: 'score',
    created: 'created',              // ISO 8601
    /* The one threading signal that has stayed true. Comments were flat siblings in
       2026-08-12 and are DOM-nested as of 2026-08-14, and in both shapes `depth` describes
       the thread correctly — verified 25/25 against DOM nesting. Build the tree from this,
       never from the DOM shape. See ARCHITECTURE §1.4. */
    depth: 'depth',
    position: 'comment-position',
    parentPositions: 'comment-parent-positions',
    permalink: 'permalink',
    contentType: 'content-type',
    awards: 'award-count'
  },
  COMMENT_BODY: '[slot="comment"]',
  /* User (author) flair — the pill beside a username. Reddit server-renders it in the
     comment's `[slot="commentMeta"]` (and beside the author on a post) as
       author-flair-event-handler > … > span.author-flair > div.flair-content
     with emoji as `.flair-image` <img>/<faceplate-img>. The `author-flair-event-handler`
     ancestor is what separates it from LINK flair, which uses `.flair-content` too but
     sits inside `shreddit-post-flair`. An empty handler is ordinary (no flair set; the
     "Top 1% Commenter" badge beside it is `community-achievements-flair`, not flair).
     Source: shreddit's own stylesheet (`shreddit-comment .author-flair`, `.flair-image`)
     and the extensions that read it; not yet re-measured by verify:live.
     SIGNED-IN ONLY: Reddit stopped sending user flair to logged-out visitors (checked by
     hand on Chrome and Firefox, 2026-10-24), so logged out this finds nothing and the
     tagline is bare by design — not a broken selector. */
  AUTHOR_FLAIR: 'author-flair-event-handler .flair-content',
  /* Flair emoji are only ever drawn from these hosts — never relax to *.redditmedia.com
     (see THUMB_HOSTS for what `styles.` would bring in). */
  FLAIR_EMOJI_HOSTS: /^(emoji\.redditmedia\.com|i\.redd\.it|preview\.redd\.it)$/,
  /* CANDIDATE, unverified live — deliberately NOT in COMMENT_ATTR, whose entries
     verify:live requires on EVERY comment; this one is expected on none of most threads.
     Reported 2026-08-27 (bug 89): subreddits that hide young comments' scores ship a
     placeholder score="1" — so every comment on an active thread read "1 point" — with
     `score_hidden: true` confirmed in the thread's own JSON. Whether the ELEMENT mirrors
     the flag is unmeasured (the report audited the JSON, not the attributes);
     `score-hidden` is the kebab-case mapping every other JSON field on this element
     follows. Read as PRESENCE, and fail-safe by construction: if Reddit never renders
     the attribute, behaviour is exactly today's — the placeholder shows — and
     verify:live's COMMENT SCORE HIDING note is what settles the name. */
  COMMENT_SCORE_HIDDEN: 'score-hidden',

  /* ---------- user profiles ---------- */
  /**
   * The element a PROFILE page's comments arrive in.
   *
   * CAPTURED LIVE 2026-08-21, on three profiles — /user/spez/ (30
   * comments), /user/GallowBoob/ (4) and /user/-eDgAR-/ (4) — all agreeing. The TAG was
   * guessed right in 0.10.0; everything else about it was wrong, which is why every live
   * profile handed back with `profile-unreadable`. It shares NOTHING with
   * `<shreddit-comment>`:
   *
   *     comment-id="t1_p1wosm9"      NOT thingid
   *     href="/r/RoastMe/comments/1u8nbai/comment/os9obnq/?context=3"   NOT permalink
   *     data-feed-element-id, reload-url, item-state, telemetry-*
   *     NO author, NO score, NO created, NO depth attribute at all
   *     NO [slot="comment"] child — hasSlotComment was false on every one
   *
   * So the reject was the design working: the element was found and stamped (the capture
   * shows `data-shd=done` on it), then rejected for want of `thingid`/`permalink`.
   *
   * Note what is NOT here and has to be derived — see model.profileComment():
   *   author      the profile owner. A profile page's comments are all theirs by
   *               definition, so the route supplies it.
   *   subreddit   only inferable from the href path, which comes in TWO shapes:
   *               /r/<sub>/comments/... and /user/<name>/comments/... (a comment on a
   *               PROFILE POST). Both are real; the fixture carries both.
   *   score       nowhere. Omitted rather than invented.
   *   created     no attribute; a <time datetime> inside the element is the only hope,
   *               and it is optional.
   */
  PROFILE_COMMENT: 'shreddit-profile-comment',
  PROFILE_COMMENT_ATTR: {
    id: 'comment-id',                // t1_xxxxx
    href: 'href'                     // already ?context=3 — permalink is this minus the query
  },
  /**
   * Where a profile comment's rendered text lives. CANDIDATES, in preference order, and
   * this is the one part of the profile contract still unmeasured: live testing established
   * that `[slot="comment"]` is NOT it (hasSlotComment: false on every captured element)
   * but did not dump the element's inner DOM. `.md` is Reddit's markdown container class,
   * which every capture of every OTHER comment body has carried, so it is the strong
   * candidate rather than a shot in the dark.
   *
   * A body is REQUIRED by model.profileComment(), deliberately: a comment row without its
   * text is worse than no row, so if this selector is wrong the page hands back rather
   * than rendering empty rows. Being wrong here costs the feature, not the page.
   */
  PROFILE_COMMENT_BODY: '[slot="comment"], .md',
  /**
   * Where a profile comment says WHICH COMMUNITY it is in, and WHAT POST it replies to.
   *
   * Both are OPPORTUNISTIC and neither is a verified contract — read the note on
   * PROFILE_COMMENT above and then this, because the two captures we have disagree:
   *
   *   2026-08-21, /user/spez/   href="/r/RoastMe/comments/1u8nbai/comment/os9obnq/?context=3"
   *   2026-08-22, /user/spez/   href="/user/spez/comments/1vgbkge/comment/p1wosm9/?context=3"
   *
   * Same profile, one day apart, and the second shape is user-scoped for EVERY comment on
   * the page — which is why deriving the community from the href's first segment printed
   * "comment in u/spez" thirty times out of thirty (live testing, bug 72). A permalink that a
   * profile page rewrites to be about the profile cannot tell us where the comment lives,
   * and no amount of parsing changes that.
   *
   * So these look for the RENDERED links instead: a real anchor to /r/<sub>/ is evidence,
   * where a rewritten path is not. They are deliberately loose — a bare prefix, validated
   * by shape in model.profileComment() rather than by a longer selector — because nothing
   * about the surrounding markup has been captured and a specific selector built on a
   * guess fails silently. A miss costs the parent line and nothing else: model.js omits
   * what it cannot establish rather than falling back to the answer we know is wrong.
   */
  PROFILE_COMMENT_SUB_LINK: 'a[href^="/r/"]',
  PROFILE_COMMENT_POST_LINK: 'a[href*="/comments/"]',

  /* Reddit locks body scroll while one of its own modals is up, and the 18+ age gate is one.
     This is the ONLY usable signal for it — captured live 2026-08-14 on a real 18+ subreddit:

       body.rpl-scroll-lock   present only while the gate is showing, gone once dismissed
       body overflow          "hidden" during, "hidden scroll" otherwise
       shreddit-app           gets NEITHER aria-hidden NOR inert — no accessibility signal
       role="dialog"          useless: ten matched on the live page, all hovercards and
                              tooltips, and the real gate was not among them

     The gate itself is `div.dialog-panel` inside a shadow root within shreddit-app, with its
     buttons as light-DOM children projected through a <slot>. We deliberately do not select
     on any of that — it is Reddit's internal component structure and far more likely to churn
     than a scroll lock, which has to exist for as long as modals do.

     `rpl-` is Reddit's design-system prefix, so this covers every Reddit modal, not just the
     age gate. POLICY (project decision, 2026-08-20): every one of them is suppressed — the
     layout never yields to a popup, and gate.js strips this class wherever it appears on a
     page we are rendering so the scroll keeps working underneath. The earlier policy
     (stand aside so the user can answer) lives on only in the engineering log's history, bugs 30-38.
     The one modal that is REMOVED outright rather than merely hidden is NATIVE_UPSELL
     directly below — left in the DOM it re-raises its lock. */
  NATIVE_MODAL_CLASS: 'rpl-scroll-lock',

  /**
   * The 18+ age gate, for ANSWERING it. Policy decision 2026-08-20: when the gate can be
   * identified with confidence, the extension clicks Reddit's own affirmative button. That is strictly better than hiding
   * the gate — Reddit clears its own lock, remembers the answer, and the pagination
   * endpoint serves an attested session, which retires the suppress-only open question.
   *
   * Anatomy from the 2026-08-18 live capture: the host is a direct child of shreddit-app
   * carrying classes `rpl-dialog configured-xpromo configured-xpromo-modal` (NEVER anchor
   * on its full id — the `bypassable` / `desktop` suffixes are variant names), with an
   * open shadow root whose panel wraps a <slot> — so the BUTTONS ARE LIGHT-DOM and a
   * plain querySelectorAll('button') on the host reaches them from the isolated world.
   *
   * TWO INDEPENDENT GUARDS, because either alone leaves the other's hole open, and they
   * need separate mutation rows for the same reason.
   *
   *   STRUCTURAL — `configured-xpromo-modal`, not `configured-xpromo`. The bare class is
   *   Reddit's CROSS-PROMOTION container, not the age gate's: it dresses "Open in app"
   *   interstitials and every other promo Reddit raises. The `-modal` suffix is the
   *   blocking-dialog variant, which is the shape the gate actually has.
   *
   *   TEXTUAL — affirm requires the literal `18`. It used to accept a bare "yes", and an
   *   "Open in app" prompt offering `Yes` / `Not now` satisfied every other test here:
   *   `\bno\b` does not match "Not", so the decline test cleared it, leaving exactly one
   *   affirmative match and a click on an app-install control. A gate that is asking
   *   about age says so; a promo does not.
   *
   * AFFIRM/DECLINE are text tests because no stable attribute was captured. THE TRAP: a
   * decline button's text can legitimately contain "18" ("No, I am under 18") — which is
   * why requiring `18` cannot stand alone — and the wrong button NAVIGATES AWAY, which is
   * the one failure mode worse than doing nothing. gate.js therefore clicks only when
   * EXACTLY ONE button matches affirm and not decline; any other outcome falls back to
   * suppression, the pre-click behaviour. Every miss costs the click and nothing else, so
   * both tests are deliberately biased towards refusing.
   */
  AGE_GATE: {
    host: '.configured-xpromo-modal',
    affirm: /\b18\b/i,
    decline: /\bno\b|\bnot\b|\bunder\b|\bback\b|\bleave\b|\bcancel\b/i
  },

  /* The exception. Captured live: `desktop_auth_blocking_upsell`, a login/signup upsell that
     fires client-side roughly 30s after page load — not on scroll, not on any interaction,
     confirmed twice with scrollY===0. It sets the SAME rpl-scroll-lock class the age gate
     does, so the "stand aside" policy this was written under (superseded above) would have
     applied to it too. That is wrong here specifically: unlike the age gate, this one
     carries no close control, and neither a real Escape keypress nor clicking its own dim
     overlay does anything — it is marked `blocking` and means it. Standing aside would trap
     a logged-out reader behind an unremovable "Get Started" / "I already have an account"
     wall with no way back except signing up — precisely what the scope section of
     CONTRIBUTING says this project exists to remove, and worse than doing nothing at all:
     without Sheddit the reader is at least looking at Reddit's own broken UX, not one we
     handed them.

     So this one specific, verified case is REMOVED rather than deferred to — see
     gate.suppressKnownUpsells(). Everything else is only HIDDEN, never deleted (the policy
     above): deleting nodes we cannot name risks breaking a flow nobody has captured, and
     generalising "remove every blocking modal" from this one example would be exactly the
     wrong lesson to take from it.

     Delivery mechanism, for context (not selected on — see the note on why below): the page
     ships a `<template id="deferred-desktop_auth_blocking_upsell">` inert in the initial
     HTML, plus a `<faceplate-partial name="ActivateExperience_..." loading="programmatic">`
     carrying `<input name="experienceKey" value="desktop_auth_blocking_upsell">` as a direct
     child of shreddit-app. ~30s in, that partial fetches
     `/svc/shreddit/partial/<hash>/activate-experience`, whose response clones the template
     into a plain <div>; the resulting custom element's own lifecycle calls a `showModal()`-
     style method immediately. Nothing client-side gates it — no cookie or localStorage key
     changed before/after across two tests, and it re-fired on every reload.

     `nodes` below is deliberately the STABLE ids only. The loader/partial name hashes seen
     live (`Xk9dTu`, `Zfxklh`) are build-specific and will rotate on Reddit's next deploy;
     anchoring on them would break silently. Both elements are direct children of
     shreddit-app, matching the age gate's shape, and BOTH must be selected: the host
     (`desktop-dynamic-upsell-modal`) renders nothing itself — the actual visible dialog is
     the portaled `#desktop-dynamic-upsell-dialog` sibling, and hiding the host alone was
     confirmed live to do nothing.

     FORMER LIMITATION, moot under the 2026-08-20 policy (gate.stripScrollLock() now clears
     the lock on every page we render, age gate or not), kept as history: an 18+ age gate and
     this upsell being up AT THE SAME TIME. Removing the upsell also clears rpl-scroll-lock,
     because that is the only way to stop deferring to a wall we just deleted — but if a real
     age gate were also showing, clearing it would un-defer and re-hide the gate, which is
     bug 30 all over again. There is no second signal to tell the two apart: the age gate is
     `div.dialog-panel` inside a shadow root, `role="dialog"` matched ten unrelated hovercards
     on the live page, and shreddit-app carries neither aria-hidden nor inert. The common case
     (upsell alone) is handled correctly and the alternative — never clearing the class — is
     wrong in that far more likely case, so this is deliberate. If the pair is ever seen
     together, that is the moment to find a real discriminator, not before. */
  NATIVE_UPSELL: {
    nodes: '#desktop-dynamic-upsell-dialog, desktop-dynamic-upsell-modal'
  },

  /* ---------- the account layer (0.34.0) ---------- */
  /**
   * Is the reader logged in to Reddit? Two selector LISTS, and the decision is:
   *
   *     logged in  =  something in `loggedIn` matches  AND  nothing in `loggedOut` does
   *
   * Presence-based on purpose. An absence-based test ("no login link, so logged in")
   * turns the account layer ON for the primary, logged-out reader the moment Reddit
   * moves its login button — which is the one direction of error this must never take.
   * A wrong guess here therefore costs the FEATURE (a logged-in reader gets 0.33.0's
   * behaviour, with the native controls still one passthrough away), never the page,
   * and never a logged-out reader's experience.
   *
   * VERIFIED LIVE 2026-09-05, signed in (`verify:live -- --headed --login`, /r/programming/):
   * `shreddit-app[user-logged-in="true"]` matched 1, `#expand-user-drawer-button` matched 1,
   * `reddit-header-large [id*="user-drawer" i]` matched 3, and both logged-out veto clauses
   * matched 0 — so the page read as LOGGED IN through three independent signals. A fourth
   * candidate, `user-drawer-app`, matched nothing and was deleted (the rule this comment
   * used to end with). The attribute is the strongest of the three: it is on the app
   * element itself, in the initial HTML, and sits beside `loid` in a list of session
   * bookkeeping — the header buttons are the fallback for the day it is renamed. The
   * logged-out veto is the header's own login button, which logged-out captures have shown
   * (a `faceplate-tracker[noun="login"]` wrapping an anchor onto /login).
   *
   * Do not add an absence-based clause — see above.
   */
  SESSION: {
    loggedIn: 'shreddit-app[user-logged-in="true"], #expand-user-drawer-button, ' +
              'reddit-header-large [id*="user-drawer" i]',
    loggedOut: 'reddit-header-large a[href*="/login"], faceplate-tracker[noun="login"]',
    /**
     * The reader's OWN name, for the header's account corner — an anchor onto their
     * profile in Reddit's own header. CANDIDATES, unverified: the signed-in probe dumped
     * `shreddit-app`'s attributes and there is no username among them (`loid` is a
     * tracking id, not a name), so the header's own link is the place to look. Every
     * clause is scoped to the header or the drawer, because `a[href^="/user/"]` matched
     * document-wide would pick the author of the first post on the page and greet the
     * reader by a stranger's name — the worst failure available to this feature, and the
     * reason the scoping is not a nicety.
     *
     * `*=` rather than `^=` because Reddit has shipped both a bare path and a full
     * `https://www.reddit.com/user/x/` in its own markup, and `^="/user/"` matches only
     * the first — the scoping above is what makes the looser operator safe, not the
     * anchor. session.js then reads the NAME OUT OF THE HREF, resolving it against the
     * page and demanding the whole PATH match `/user/<name>/`, so a link to a comment or
     * a profile tab cannot be mistaken for an identity; it takes the first candidate that
     * parses, so a `/user/me/` alias sitting beside the real link is stepped over rather
     * than mistaken for a name. A miss costs the name and nothing else: the corner says
     * "logged in" instead, and the preferences link beside it is unaffected.
     */
    /* THE NAME IS AN ATTRIBUTE, NOT A LINK, and it is there from the first byte. Measured
       live 2026-09-17 on a listing, a comments page and a profile: none of the anchor
       clauses below match at load, because the only `/user/<me>/` link on the page is the
       "View Profile" row inside #user-drawer-content, and that content is not in the DOM
       until the drawer has been opened once. Polled 0-9s after load: no profile link, so
       the corner said "logged in" and the menu had no profile entry, on every page.
       What IS in the page at t=0 is
         shreddit-app > after-login-toast-dispatcher[username="<me>"]
       a direct child of the app element. Direct child is the scoping: nothing that deep
       in a post or a comment can be mistaken for it, which is the property every other
       clause here exists to secure. `achievements-entrypoint[username]` carries the same
       value in the right rail, and is deliberately NOT listed: it has not been seen on
       another user's profile page, where "username" could as easily name the profile's
       owner, and greeting the reader by a stranger's name is the failure this contract is
       built around. Read as an attribute value, so session.js's href parsing does not
       apply; the anchors below remain the fallback for a page without the dispatcher. */
    usernameAttr: 'shreddit-app > after-login-toast-dispatcher[username]',
    username: 'reddit-header-large a[href*="/user/"], ' +
              '#expand-user-drawer-button a[href*="/user/"], ' +
              'user-drawer-app a[href*="/user/"], ' +
              '[id*="user-drawer" i] a[href*="/user/"], ' +
              'faceplate-tracker[noun*="user_drawer" i] a[href*="/user/"], ' +
              'faceplate-tracker[source="account_manager"] a[href*="/user/"]',
    /* The avatar Reddit already drew in its own header. Rendering our own <img> from that
       URL costs no request the browser has not already made — it is the thumbnail
       arrangement exactly (model.js), one cached file. Optional in the strictest sense:
       no avatar, no <img>, and the corner still names the reader. */
    avatar: '#expand-user-drawer-button img, #expand-user-drawer-button faceplate-img, ' +
            'reddit-header-large img[alt*="avatar" i]'
  },

  /**
   * Where a logged-in reader manages their account. Reddit's own route, which Sheddit
   * never renders — `route.js` classifies it OTHER and the gate never suppresses it, so
   * the link lands on the page Reddit built for the job, exactly as the submit doors do.
   * A trailing slash because every other path this file hands out carries one.
   */
  ACCOUNT: {
    settings: '/settings/',
    inbox: '/message/inbox/',
    /* Appended to the reader's own profile: /user/<name>/saved/. Reddit's, not ours. */
    savedTab: 'saved',
    /* Reddit's unread-notifications count, measured signed in 2026-11-01: the header's
       bell is `a#notifications-inbox-button[href="/notifications"]`, and while anything is
       unread it holds `dynamic-badge[initial-count="N"]`. With nothing unread there is no
       badge at all. */
    notifications: '/notifications',
    unreadBadge: '#notifications-inbox-button dynamic-badge',
    unreadCountAttr: 'initial-count',
    /* Reddit's login page, for the corner's logged-out state. A LINK, and only ever
       reached by a deliberate click on it — this is not the extension asking anyone to
       log in. See the scope note in CONTRIBUTING, which this reversed by owner decision
       on 2026-09-09: the objection was always to Reddit's unremovable interstitial, not
       to a reader who keeps an account being told where the door is. */
    login: '/login/'
  },

  /**
   * Reddit's own user drawer — the panel its avatar button opens, and the only place a
   * logged-in session's LOG OUT control has ever been seen. The account layer opens it
   * the way a reader would (a click on Reddit's own toggle) and clicks Reddit's own item
   * inside it; Reddit's code then ends the session, exactly as it would have.
   *
   * `toggle` is the avatar button, which C.SESSION.loggedIn also matches — the same
   * element answering two questions, deliberately, rather than two selectors that can
   * drift apart. `host` is where the opened drawer's content lands: listed separately
   * because a portaled panel is a sibling of the header rather than a descendant (the
   * upsell dialog taught that — see NATIVE_UPSELL), so a search scoped to the header
   * alone would miss it.
   */
  USER_DRAWER: {
    toggle: '#expand-user-drawer-button, reddit-header-large [id*="user-drawer" i] button',
    /* The panel itself, named, and searched BEFORE `host`. The loose `[id*="user-drawer"]`
       clause below also matches faceplate-partial#user-drawer-avatar-logged-in — which is
       the avatar, and it lives INSIDE the toggle button. Measured live: the "reveal Reddit's
       own drawer" fallback revealed that partial, and passthrough() then display:none'd
       every sibling on the way down to it, #user-drawer-content among them. The reader got
       a dark page with their avatar alone at top-left and the drawer nowhere. Same class of
       bug the toggle exclusion was written for, one level down. */
    content: '#user-drawer-content',
    host: '[id*="user-drawer" i], user-drawer-app, faceplate-tracker[noun*="user_drawer" i]'
  },

  /**
   * Reddit's own comment composer, which account.js DRIVES rather than replaces: the
   * reader types into an old-reddit reply box of ours, and on save the text is handed to
   * Reddit's editor and Reddit's submit button is clicked. Reddit's code then owns the
   * request, the auth, the error handling and the optimistic insert — exactly the
   * division vote delegation has always had (ARCHITECTURE §5), and the reason the
   * extension still makes no request of its own.
   *
   * VERIFIED LIVE 2026-09-05, signed in, for the TOP-LEVEL composer a logged-in thread
   * carries: every `host` clause matched exactly one element (nested — the async loader
   * outermost, then comment-composer-host, shreddit-composer, faceplate-form), the first
   * in document order being <shreddit-async-loader bundlename=…composer…>, outside any
   * comment; the `editor` inside it is
   *   <div slot name contenteditable role tabindex aria-placeholder data-lexical-editor dir>
   * — Reddit's rich-text editor is Lexical, which is why account.js feeds a contenteditable
   * through the browser's own editing command (Lexical listens for beforeinput; a direct
   * text set is reconciled away) — and the `submit` is <button rpl slot type> "Comment".
   * `[data-lexical-editor]` is listed so the contract names what was seen; the
   * contenteditable clauses are the generic fallback.
   *
   * NOW VERIFIED, and the answer is no — measured on a signed-in thread, both directions:
   *
   *   composer state                | execCommand | synthetic paste | textContent =
   *   collapsed (what we hit first) | false       | nothing lands   | reconciled away
   *   after a TRUSTED user click    | works       | works           | reconciled away
   *
   * Two things follow, and both are in account.js rather than here because neither is a
   * selector problem. Reddit mounts that editor only on a real user gesture: `host.click()`
   * and a full pointerdown/mousedown/pointerup/mouseup/click sequence on the placeholder
   * both produced no editor, no submit button and `execCommand` still false. A content
   * script cannot fake activation and that is the end of it. And `textContent =` never
   * works against Lexical in either state, so account.js refuses that fallback for the
   * measured richEditor selector. Browser edits still have to survive reconciliation
   * (landed()) before submission.
   *
   * What the ceiling actually costs is one extra click: the reader opens Reddit's box
   * themselves, it stays open, and a second save then completes the whole chain. That is
   * what the handoff now tells them to do.
   *
   * The PER-COMMENT composer does NOT have that ceiling — measured (log 112): a save on a
   * comment reached the insert step, which is past the liveness gate, so Reddit mounted a
   * real composer with its submit control from our untrusted click on `C.NATIVE.reply`.
   * Only the top-level box is gated on a genuine gesture. What the per-comment path has
   * instead is non-determinism: the reply control is on the lazily-hydrated action row and
   * was not found at all on one of three saves (open question 18).
   *
   * Two more things the same session measured about the editor, both handled in
   * account.js: `textContent` of adjacent <p> nodes concatenates with NO separator, so any
   * comparison against a multi-line draft has to drop whitespace on both sides rather than
   * collapse it; and `focus()` on the editor is refused while suppression inherits
   * visibility:hidden. account.js temporarily overrides only the editor's visibility,
   * retaining native opacity and click suppression, then verifies focus before editing.
   * Without that check, `execCommand` writes into whatever IS focused — which was the
   * reader's own draft box.
   * Neither is a selector problem, which is why neither lives here. Each miss has the same fail-safe: the native composer is revealed in place
   * (passthrough), and the reader finishes in Reddit's UI. account.js's `compose()`
   * measures the outcome — a new comment element arriving under the target — rather than
   * assuming the click worked (the "N more replies" lesson, log bug 70).
   */
  COMPOSER: {
    host: 'comment-composer-host, shreddit-composer, shreddit-async-loader[bundlename*="composer" i], ' +
          'faceplate-form[action*="comment" i]',
    editor: 'textarea, [data-lexical-editor], [contenteditable="true"], [contenteditable=""]',
    richEditor: '[data-lexical-editor]',
    submit: 'button[type="submit"], [slot="submit-button"], button[slot*="submit" i]',
    /* THE COLLAPSED STATE, measured live 2026-09-17 on a top-level composer:
         comment-composer-host[slot=ready]
           faceplate-textarea-input[data-testid=trigger-button size=collapsed]  visible
           faceplate-form[slot=ready] > shreddit-composer                      hidden
             div[slot=rte][contenteditable][data-lexical-editor]               hidden
             button[type=submit] "Comment"                                     hidden, enabled
       The submit button is PRESENT while collapsed. 0.48.0 discriminated open from
       collapsed by its presence — on the measurement then available, a collapsed box had
       none — and the markup has moved under that: deepQuery found the hidden button, the
       box was taken for open, and the insert went into an editor with no model (log 113).
       Open and collapsed differ by VISIBILITY, not by what exists, so account.js reads
       that; this names the trigger so the collapsed state can be recognised and opened.
       What opens it is FOCUS on the textarea inside the trigger's shadow root — clicking
       the trigger does nothing, a real pointer sequence did nothing (log 111), and a focus
       call expands it in ~300ms. The host also exposes focus() on its prototype. */
    trigger: 'faceplate-textarea-input[data-testid="trigger-button"]',
    /* THE MARKDOWN EDITOR, measured live 2026-11-01, signed in. The rich editor posts
       `mode=richText`, so `**bold**` typed into our old-reddit box arrived literally. Its
       toolbar has a "Switch to Markdown" button that swaps in a plain <textarea> inside
       shreddit-markdown-composer's shadow root, and the same submit then sends
       `mode=markdown` with the raw text. Reddit remembers the choice across reloads. */
    toMarkdown: 'button[aria-label="Switch to Markdown"]',
    markdownHost: 'shreddit-markdown-composer',
    /* A REJECTED SUBMIT, measured live 2026-11-01: create-comment answers 200 with a
       partial that inserts, in the light DOM under the comment tree,
         <faceplate-alert level="error" message="Rate limit exceeded. Please wait 9 minutes
           and try again" data-action-info-error-codes='["RATE_LIMITED"]'>
       and Reddit shows the message as a toast. No comment is created. */
    error: 'faceplate-alert[level="error"][message]'
  },

  /**
   * Where a new post is written: Reddit's own composer, on its own route, which Sheddit
   * never renders (route.js classifies it OTHER and the gate never suppresses it — it is
   * one of the routes CONTRIBUTING says to leave completely untouched). Old reddit's
   * sidebar offered the two doors to it, "Submit a new link" and "Submit a new text
   * post", and that is what the account layer offers: a link onto this path, with the
   * type Reddit's composer reads from the query. The values are Reddit's; `/submit` with
   * no subreddit is the front page's, where Reddit asks which community.
   */
  SUBMIT: {
    path: 'submit',
    types: { link: 'LINK', text: 'TEXT' }
  },

  /* ---------- our own markers ---------- */
  MARK: 'data-shd',                  // stamped "done" on consumed source elements
  ROOT_ID: 'shd-root',
  BODY_CLASS: 'shd-active'
};

/* Feature toggles; overridden from chrome.storage.sync by pipeline.js */
SHD.settings = {
  listing: true,
  comments: true,
  chrome: true,
  /* User profile pages (/user/<name>/ and its comments/submitted tabs). In scope by owner
     decision 2026-08-21; the profile COMMENT contract is unverified (see C.PROFILE_COMMENT),
     so a profile that cannot be read hands back native Reddit quietly rather than failing. */
  profiles: true,
  compactRows: true,
  showThumbnails: true,
  /* Adult-content thumbnails, off by default — which is both the safer default and the
     faithful one. Reddit blurs them in its own feed for logged-out readers and old reddit
     hid them behind a placeholder tile unless you opted in, so fidelity and not putting
     graphic imagery in front of someone who did not ask for it agree here, the same way
     they did for save/report. `true` shows the real image, as the opt-in did. */
  showNsfwThumbnails: false,
  autoPaginate: true,       // false => "load more" becomes a manual button
  /* Play video inside the comments page instead of only linking to it. This is the ONE
     setting that costs a network request — one GET of a static manifest per video post
     opened, and only then (see media.js and PRIVACY.md). On by default because without it
     a repackaged asset is simply unwatchable with the extension on, which is the bug that
     prompted it; a reader who would rather the extension keep making no requests at all
     turns it off here and gets the pre-0.16.0 behaviour exactly. Since 0.17.0 the player
     also carries the post's SOUND, which on a CMAF asset is a second file played alongside
     the picture — still one request of ours, the manifest, which names both. */
  inlineVideo: true,
  /* Show the post's own picture: open on its comments page, and behind old reddit's
     expando on a listing row. Costs no request of ours — the URL is already in the page
     and the browser fetches the file the same way it fetches a thumbnail, on the row only
     once the reader opens it.
     Adult posts are NOT covered by this: they answer to showNsfwThumbnails above, exactly
     as the thumbnail does, because rendering our own <img> is what walks past the blur
     Reddit applies for logged-out readers and a full-size copy is that same bypass. Both
     settings must say yes. */
  inlineImages: true,
  /* Ask GitHub for the current version number once when the browser starts, instead of
     waiting for the header's control to be pressed. On by default, and the reason is the
     failure it prevents: a hand-installed copy never updates itself, so the reader most
     likely to be running a broken build is the one who set this up months ago and has not
     thought about it since — and a notice that has to be pressed is a notice they never
     see. Off means off: no request leaves at startup, and the button still answers on a
     click exactly as it did before. Rate-limited in background.js, because "at browser
     start" is not a rate. */
  autoUpdateCheck: true,
  /* Send a link to old.reddit.com to www.reddit.com instead, behind an interstitial that
     says so. On by default because old.reddit.com stopped serving logged-out readers —
     every path there answers with a login wall — and a Reddit link that dead-ends is
     blamed on the extension that is installed, not on the host that retired. Turn it off
     and old.reddit.com is left exactly as it is, which is what a reader who can still log
     in there wants.

     The one setting no code in this file's world ever reads: it belongs to
     src/core/oldreddit.js, which ships ALONE on old.reddit.com and repeats the default
     rather than being handed 900 lines of selectors for a page it is leaving. test/run.js
     asserts the two agree — the arrangement bridge.js has with BRIDGE. */
  redirectOldReddit: true,
  /* The account layer: vote arrows that register, an old-reddit reply box, and the
     sidebar's "submit" buttons — for a reader who is ALREADY logged in to Reddit. On by
     default because it does nothing at all for a logged-out reader (SHD.session decides,
     and every one of its signals is presence-based, so the primary use case is untouched
     by construction), and because a logged-in reader who installed an old-reddit skin
     expects old reddit's arrows to work. Off here and a logged-in session reads exactly
     as 0.33.0 did: arrows decorative, `reply` a handoff to Reddit's own comment.

     Nothing in this layer makes a request of Sheddit's own, logged in or out. Every action
     is a click forwarded to the control Reddit rendered for the same purpose, and text
     handed to Reddit's own editor; Reddit's page code makes the request it would have made
     had the reader used Reddit's button — see PRIVACY.md. */
  account: true,
  /* Which palette to paint in. The ids live in src/config/themes.js, which also owns the
     fallback: anything not on that list resolves to 'classic'. This is the one setting
     that is not a boolean, and the only one a page can change by itself — the header's
     theme buttons write it. */
  theme: 'classic'
};

/* There is deliberately no `pruneAfterRender`. It shipped as a documented memory
   mitigation whose implementation was an empty callback, and it cannot be implemented as
   specified: vote delegation resolves Reddit's native controls out of `m.source` AT CLICK
   TIME (ARCHITECTURE §5), so detaching a rendered post's subtree is exactly what breaks
   voting on every post the user has scrolled past. Reddit's own infinite scroll retains
   the same nodes, so we are not making the page heavier than it would otherwise be. If
   memory ever needs capping, drop whole rendered ROWS off the top of #siteTable and let
   the source elements go with them — do not gut live posts. */
